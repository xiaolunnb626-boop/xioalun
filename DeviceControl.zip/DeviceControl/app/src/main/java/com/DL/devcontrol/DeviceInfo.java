package com.DL.devcontrol;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.UUID;

/** 收集本机设备信息：型号、系统版本、处理器、电量等。只读，不上传到任何外部服务器。 */
final class DeviceInfo {

    private DeviceInfo() { }

    /** 本机的稳定标识，首次调用时生成并持久化 */
    static String deviceId(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("devctl", Context.MODE_PRIVATE);
        String id = sp.getString("device_id", null);
        if (id == null) {
            id = UUID.randomUUID().toString();
            sp.edit().putString("device_id", id).apply();
        }
        return id;
    }

    static JSONObject collect(Context ctx) {
        JSONObject o = new JSONObject();
        put(o, "model", Build.MODEL);
        put(o, "manufacturer", Build.MANUFACTURER);
        put(o, "release", Build.VERSION.RELEASE);
        put(o, "sdk", Build.VERSION.SDK_INT);
        put(o, "abi", primaryAbi());
        put(o, "cores", Runtime.getRuntime().availableProcessors());
        String hw = cpuHardware();
        if (hw != null) put(o, "cpuHardware", hw);

        try {
            Intent bi = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bi != null) {
                int level = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) put(o, "battery", Math.round(level * 100f / scale));
                int status = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL;
                put(o, "charging", charging);
            }
        } catch (Throwable ignored) { }

        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            put(o, "ramTotalGB", mi.totalMem / 1073741824.0);
            put(o, "ramAvailGB", mi.availMem / 1073741824.0);
        } catch (Throwable ignored) { }

        try {
            StatFs sf = new StatFs(Environment.getExternalStorageDirectory().getPath());
            double freeGB = (sf.getAvailableBlocksLong() * sf.getBlockSizeLong()) / 1073741824.0;
            put(o, "storageFreeGB", freeGB);
        } catch (Throwable ignored) { }

        try {
            put(o, "appVer", ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName);
        } catch (Throwable ignored) { }

        return o;
    }

    private static String primaryAbi() {
        try {
            String[] abis = Build.SUPPORTED_ABIS;
            if (abis != null && abis.length > 0) return abis[0];
        } catch (Throwable ignored) { }
        try {
            //noinspection deprecation
            return Build.CPU_ABI;
        } catch (Throwable ignored) {
            return null;
        }
    }

    /** 读取 /proc/cpuinfo 的 Hardware / model name 字段；不少新系统会限制读取，读不到就返回 null */
    private static String cpuHardware() {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("/proc/cpuinfo"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("Hardware") || line.startsWith("model name")) {
                    int idx = line.indexOf(':');
                    if (idx >= 0) return line.substring(idx + 1).trim();
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Throwable ignored) { }
            }
        }
        return null;
    }

    private static void put(JSONObject o, String k, Object v) {
        try {
            o.put(k, v);
        } catch (JSONException ignored) { }
    }
}
