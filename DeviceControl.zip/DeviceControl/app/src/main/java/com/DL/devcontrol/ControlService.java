package com.DL.devcontrol;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 局域网设备管控服务：既可以当「主机」接受已授权设备连接、展示它们的设备信息，
 * 也可以当「用户端」连接到主机、持续上报本机设备信息。只在同一局域网内通信，
 * 不连接任何外部服务器；授权码只用来防止同一局域网里其他人误连，不是强加密。
 */
public class ControlService extends Service {

    static final int PORT = 47562;

    static final String ACTION_START_HOST = "com.DL.devcontrol.START_HOST";
    static final String ACTION_STOP_HOST = "com.DL.devcontrol.STOP_HOST";
    static final String ACTION_START_CLIENT = "com.DL.devcontrol.START_CLIENT";
    static final String ACTION_STOP_CLIENT = "com.DL.devcontrol.STOP_CLIENT";
    static final String ACTION_KICK = "com.DL.devcontrol.KICK";

    static final String EXTRA_CODE = "code";
    static final String EXTRA_IP = "ip";
    static final String EXTRA_DEVICE_ID = "deviceId";

    private static final String CHANNEL_ID = "devctl";
    private static final int NOTI_ID = 1;

    interface Listener {
        void onChanged();
    }

    private static volatile ControlService instance;
    private static volatile Listener listener;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Object devicesLock = new Object();
    private final LinkedHashMap<String, JSONObject> devices = new LinkedHashMap<String, JSONObject>();
    private final ConcurrentHashMap<String, Socket> sockets = new ConcurrentHashMap<String, Socket>();

    private volatile boolean hostRunning;
    private volatile String hostCode;
    private volatile ServerSocket serverSocket;
    private volatile String hostStatus = "服务未启动";

    private volatile boolean clientRunning;
    private volatile Socket clientSocket;
    private volatile String clientStatus = "未连接";

    // ======================= 静态入口：供界面读取状态、下发操作 =======================

    static void setListener(Listener l) {
        listener = l;
    }

    static boolean isHostRunning() {
        return instance != null && instance.hostRunning;
    }

    static boolean isClientRunning() {
        return instance != null && instance.clientRunning;
    }

    static String getHostStatus() {
        return instance != null ? instance.hostStatus : "服务未启动";
    }

    static String getClientStatus() {
        return instance != null ? instance.clientStatus : "未连接";
    }

    static LinkedHashMap<String, JSONObject> snapshot() {
        if (instance == null) return new LinkedHashMap<String, JSONObject>();
        synchronized (instance.devicesLock) {
            return new LinkedHashMap<String, JSONObject>(instance.devices);
        }
    }

    // ======================= 生命周期 =======================

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_START_HOST.equals(action)) {
            startHost(intent.getStringExtra(EXTRA_CODE));
        } else if (ACTION_STOP_HOST.equals(action)) {
            stopHost();
        } else if (ACTION_START_CLIENT.equals(action)) {
            startClient(intent.getStringExtra(EXTRA_IP), intent.getStringExtra(EXTRA_CODE));
        } else if (ACTION_STOP_CLIENT.equals(action)) {
            stopClient();
        } else if (ACTION_KICK.equals(action)) {
            kickDevice(intent.getStringExtra(EXTRA_DEVICE_ID));
        }
        maybeStopForeground();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        hostRunning = false;
        clientRunning = false;
        closeQuietly(serverSocket);
        closeQuietly(clientSocket);
        for (Socket s : sockets.values()) closeQuietly(s);
        sockets.clear();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    // ======================= 主机：接受连接，展示设备信息 =======================

    private void startHost(String code) {
        if (hostRunning) return;
        if (code == null || code.length() < 8) {
            hostStatus = "授权码至少需要 8 位";
            notifyListener();
            return;
        }
        ServerSocket srv;
        try {
            srv = new ServerSocket(PORT);
        } catch (IOException e) {
            hostStatus = "启动失败：端口被占用，或没有网络权限";
            notifyListener();
            return;
        }
        serverSocket = srv;
        hostCode = code;
        hostRunning = true;
        hostStatus = "服务已启动 · 端口 " + PORT + " · 本机 IP：" + LanUtil.localIp(this);
        ensureForeground();
        notifyListener();

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (hostRunning) {
                    Socket client;
                    try {
                        client = serverSocket.accept();
                    } catch (IOException e) {
                        break;
                    }
                    if (!hostRunning) {
                        closeQuietly(client);
                        break;
                    }
                    handleClient(client);
                }
            }
        }, "devctl-accept").start();
    }

    private void handleClient(final Socket client) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String deviceId = null;
                try {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(client.getInputStream(), "UTF-8"));
                    PrintWriter writer = new PrintWriter(
                            new OutputStreamWriter(client.getOutputStream(), "UTF-8"), true);

                    String first = reader.readLine();
                    if (first == null) throw new IOException("空连接");
                    JSONObject hello = new JSONObject(first);
                    if (!"hello".equals(hello.optString("type"))) throw new IOException("协议错误");
                    if (hostCode == null || !hostCode.equals(hello.optString("code"))) {
                        safePrintln(writer, "{\"type\":\"reject\",\"reason\":\"code\"}");
                        throw new IOException("授权码错误");
                    }
                    deviceId = hello.optString("deviceId", String.valueOf(client.getInetAddress()));

                    JSONObject snap = new JSONObject(hello.toString());
                    snap.put("ip", client.getInetAddress().getHostAddress());
                    snap.put("online", true);
                    snap.put("lastSeen", System.currentTimeMillis());

                    sockets.put(deviceId, client);
                    synchronized (devicesLock) {
                        devices.put(deviceId, snap);
                    }
                    notifyListener();
                    safePrintln(writer, new JSONObject().put("type", "welcome").toString());

                    while (hostRunning) {
                        String line = reader.readLine();
                        if (line == null) break;
                        JSONObject o;
                        try {
                            o = new JSONObject(line);
                        } catch (Exception badJson) {
                            continue;
                        }
                        String t = o.optString("type");
                        if ("beat".equals(t)) {
                            applyBeat(deviceId, o);
                        } else if ("bye".equals(t)) {
                            break;
                        }
                    }
                } catch (Throwable ignored) {
                } finally {
                    closeQuietly(client);
                    final String id = deviceId;
                    if (id != null) {
                        sockets.remove(id);
                        synchronized (devicesLock) {
                            JSONObject d = devices.get(id);
                            if (d != null) {
                                try {
                                    d.put("online", false);
                                } catch (Exception ignored2) { }
                            }
                        }
                        notifyListener();
                    }
                }
            }
        }, "devctl-client").start();
    }

    private void applyBeat(String deviceId, JSONObject beat) {
        synchronized (devicesLock) {
            JSONObject d = devices.get(deviceId);
            if (d == null) return;
            try {
                if (beat.has("battery")) d.put("battery", beat.optInt("battery", -1));
                d.put("charging", beat.optBoolean("charging", false));
                if (beat.has("storageFreeGB")) d.put("storageFreeGB", beat.optDouble("storageFreeGB"));
                if (beat.has("ramAvailGB")) d.put("ramAvailGB", beat.optDouble("ramAvailGB"));
                d.put("lastSeen", System.currentTimeMillis());
            } catch (Exception ignored) { }
        }
        notifyListener();
    }

    private void kickDevice(String deviceId) {
        if (deviceId == null) return;
        Socket s = sockets.get(deviceId);
        if (s != null) closeQuietly(s);
    }

    private void stopHost() {
        if (!hostRunning) return;
        hostRunning = false;
        closeQuietly(serverSocket);
        for (Socket s : sockets.values()) closeQuietly(s);
        sockets.clear();
        synchronized (devicesLock) {
            for (JSONObject d : devices.values()) {
                try {
                    d.put("online", false);
                } catch (Exception ignored) { }
            }
        }
        hostStatus = "服务未启动";
        notifyListener();
    }

    // ======================= 用户端：连接主机并持续上报本机信息 =======================

    private void startClient(final String ip, final String code) {
        if (clientRunning) return;
        if (ip == null || ip.length() == 0) {
            clientStatus = "请输入主机 IP";
            notifyListener();
            return;
        }
        if (code == null || code.length() < 8) {
            clientStatus = "请输入授权码（至少 8 位）";
            notifyListener();
            return;
        }
        clientRunning = true;
        clientStatus = "正在连接 " + ip + " …";
        ensureForeground();
        notifyListener();

        new Thread(new Runnable() {
            @Override
            public void run() {
                Socket sock = null;
                try {
                    sock = new Socket();
                    sock.connect(new InetSocketAddress(ip, PORT), 8000);
                    clientSocket = sock;
                    PrintWriter writer = new PrintWriter(
                            new OutputStreamWriter(sock.getOutputStream(), "UTF-8"), true);
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(sock.getInputStream(), "UTF-8"));

                    JSONObject hello = DeviceInfo.collect(ControlService.this);
                    hello.put("type", "hello");
                    hello.put("code", code);
                    hello.put("deviceId", DeviceInfo.deviceId(ControlService.this));
                    writer.println(hello.toString());

                    String resp = reader.readLine();
                    if (resp == null) throw new IOException("连接被拒绝或已断开");
                    JSONObject robj = new JSONObject(resp);
                    if (!"welcome".equals(robj.optString("type"))) {
                        throw new IOException("授权码错误，或被管控端拒绝");
                    }

                    clientStatus = "已连接到 " + ip;
                    notifyListener();

                    while (clientRunning) {
                        JSONObject beat = DeviceInfo.collect(ControlService.this);
                        beat.put("type", "beat");
                        beat.put("deviceId", DeviceInfo.deviceId(ControlService.this));
                        safePrintln(writer, beat.toString());
                        for (int i = 0; i < 10 && clientRunning; i++) {
                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException ie) {
                                break;
                            }
                        }
                    }
                    safePrintln(writer, "{\"type\":\"bye\"}");
                } catch (Throwable t) {
                    String msg = t.getMessage();
                    clientStatus = "连接失败：" + (msg != null ? msg : t.toString());
                } finally {
                    closeQuietly(sock);
                    clientRunning = false;
                    clientSocket = null;
                    notifyListener();
                    maybeStopForeground();
                }
            }
        }, "devctl-join").start();
    }

    private void stopClient() {
        if (!clientRunning && clientSocket == null) return;
        clientRunning = false;
        closeQuietly(clientSocket);
        clientStatus = "未连接";
        notifyListener();
    }

    // ======================= 辅助 =======================

    private void notifyListener() {
        main.post(new Runnable() {
            @Override
            public void run() {
                Listener l = listener;
                if (l != null) l.onChanged();
            }
        });
    }

    private void ensureForeground() {
        startForeground(NOTI_ID, buildNotification());
    }

    private void maybeStopForeground() {
        if (!hostRunning && !clientRunning) {
            stopForeground(true);
            stopSelf();
        } else {
            // 状态有变化（比如主机已启动、人数变化），刷新一下通知文案
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTI_ID, buildNotification());
        }
    }

    private Notification buildNotification() {
        StringBuilder text = new StringBuilder();
        if (hostRunning) text.append("主机运行中");
        if (clientRunning) {
            if (text.length() > 0) text.append(" · ");
            text.append("已连接到主机");
        }
        if (text.length() == 0) text.append("未运行");

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(new NotificationChannel(
                        CHANNEL_ID, "设备管控", NotificationManager.IMPORTANCE_LOW));
            }
            b = new Notification.Builder(this, CHANNEL_ID);
        } else {
            b = new Notification.Builder(this);
        }
        b.setContentTitle("设备管控");
        b.setContentText(text.toString());
        b.setSmallIcon(android.R.drawable.stat_notify_sync);
        b.setOngoing(true);
        Intent open = new Intent(this, MainActivity.class);
        int flags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        b.setContentIntent(PendingIntent.getActivity(this, 0, open, flags));
        return b.build();
    }

    private static void safePrintln(PrintWriter w, String s) {
        try {
            w.println(s);
        } catch (Throwable ignored) { }
    }

    private static void closeQuietly(ServerSocket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (Throwable ignored) { }
    }

    private static void closeQuietly(Socket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (Throwable ignored) { }
    }
}
