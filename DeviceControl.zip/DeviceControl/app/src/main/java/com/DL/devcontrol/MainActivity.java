package com.DL.devcontrol;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

/** 设备管控：既可以作为主机查看局域网内已授权设备的信息，也可以作为用户端连接到主机上报本机信息。 */
public class MainActivity extends Activity implements ControlService.Listener {

    private EditText adminCodeEt, hostIpEt, joinCodeEt;
    private TextView hostStatusTv, joinStatusTv, summaryTv;
    private LinearLayout deviceListBox;
    private SharedPreferences sp;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("devctl", Context.MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(48), dp(24), dp(32));

        TextView title = new TextView(this);
        title.setText("设备管控");
        title.setTextSize(28);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("局域网内查看 / 上报设备信息，不连接任何外部服务器");
        subtitle.setTextSize(13);
        subtitle.setTextColor(Color.parseColor("#8E8E93"));
        subtitle.setPadding(0, dp(4), 0, dp(24));
        root.addView(subtitle);

        // ---------------- 主机 ----------------
        addSectionTitle(root, "管控端（查看其他设备）");

        adminCodeEt = new EditText(this);
        adminCodeEt.setHint("授权码（至少 8 位，自己设置）");
        root.addView(adminCodeEt, matchWrap());

        LinearLayout hostBtnRow = new LinearLayout(this);
        hostBtnRow.setOrientation(LinearLayout.HORIZONTAL);
        hostBtnRow.setPadding(0, dp(8), 0, 0);
        Button startHost = new Button(this);
        startHost.setText("启动管控服务");
        Button stopHost = new Button(this);
        stopHost.setText("停止服务");
        hostBtnRow.addView(startHost, weightLp());
        hostBtnRow.addView(stopHost, weightLp());
        root.addView(hostBtnRow, matchWrap());

        hostStatusTv = new TextView(this);
        hostStatusTv.setTextSize(13);
        hostStatusTv.setPadding(0, dp(8), 0, dp(4));
        hostStatusTv.setTextIsSelectable(true);
        root.addView(hostStatusTv, matchWrap());

        summaryTv = new TextView(this);
        summaryTv.setTextSize(13);
        summaryTv.setTextColor(Color.parseColor("#5A6270"));
        root.addView(summaryTv, matchWrap());

        deviceListBox = new LinearLayout(this);
        deviceListBox.setOrientation(LinearLayout.VERTICAL);
        deviceListBox.setPadding(0, dp(8), 0, dp(8));
        root.addView(deviceListBox, matchWrap());

        divider(root);

        // ---------------- 用户端 ----------------
        addSectionTitle(root, "用户端（把本机信息上报给管控端）");

        hostIpEt = new EditText(this);
        hostIpEt.setHint("管控端的局域网 IP，例如 192.168.1.5");
        root.addView(hostIpEt, matchWrap());

        joinCodeEt = new EditText(this);
        joinCodeEt.setHint("授权码（与管控端一致）");
        root.addView(joinCodeEt, matchWrap());

        LinearLayout joinBtnRow = new LinearLayout(this);
        joinBtnRow.setOrientation(LinearLayout.HORIZONTAL);
        joinBtnRow.setPadding(0, dp(8), 0, 0);
        Button join = new Button(this);
        join.setText("授权并连接");
        Button leave = new Button(this);
        leave.setText("断开连接");
        joinBtnRow.addView(join, weightLp());
        joinBtnRow.addView(leave, weightLp());
        root.addView(joinBtnRow, matchWrap());

        joinStatusTv = new TextView(this);
        joinStatusTv.setTextSize(13);
        joinStatusTv.setPadding(0, dp(8), 0, 0);
        joinStatusTv.setTextIsSelectable(true);
        root.addView(joinStatusTv, matchWrap());

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        adminCodeEt.setText(sp.getString("admin_code", ""));
        hostIpEt.setText(sp.getString("host_ip", ""));
        joinCodeEt.setText(sp.getString("admin_code", ""));

        startHost.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String code = adminCodeEt.getText().toString().trim();
                if (code.length() < 8) {
                    Toast.makeText(MainActivity.this, "授权码至少需要 8 位", Toast.LENGTH_SHORT).show();
                    return;
                }
                sp.edit().putString("admin_code", code).apply();
                Intent i = new Intent(MainActivity.this, ControlService.class)
                        .setAction(ControlService.ACTION_START_HOST)
                        .putExtra(ControlService.EXTRA_CODE, code);
                startServiceCompat(i);
            }
        });
        stopHost.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startServiceCompat(new Intent(MainActivity.this, ControlService.class)
                        .setAction(ControlService.ACTION_STOP_HOST));
            }
        });
        join.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String ip = hostIpEt.getText().toString().trim();
                String code = joinCodeEt.getText().toString().trim();
                if (ip.length() == 0) {
                    Toast.makeText(MainActivity.this, "请输入管控端的局域网 IP", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (code.length() < 8) {
                    Toast.makeText(MainActivity.this, "请输入授权码（至少 8 位）", Toast.LENGTH_SHORT).show();
                    return;
                }
                sp.edit().putString("host_ip", ip).putString("admin_code", code).apply();
                Intent i = new Intent(MainActivity.this, ControlService.class)
                        .setAction(ControlService.ACTION_START_CLIENT)
                        .putExtra(ControlService.EXTRA_IP, ip)
                        .putExtra(ControlService.EXTRA_CODE, code);
                startServiceCompat(i);
            }
        });
        leave.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startServiceCompat(new Intent(MainActivity.this, ControlService.class)
                        .setAction(ControlService.ACTION_STOP_CLIENT));
            }
        });
    }

    private void startServiceCompat(Intent i) {
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Throwable t) {
            Toast.makeText(this, "操作失败：" + t, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ControlService.setListener(this);
        refresh();
    }

    @Override
    protected void onPause() {
        ControlService.setListener(null);
        super.onPause();
    }

    @Override
    public void onChanged() {
        refresh();
    }

    private void refresh() {
        hostStatusTv.setText(ControlService.getHostStatus());
        joinStatusTv.setText(ControlService.getClientStatus());

        LinkedHashMap<String, JSONObject> devices = ControlService.snapshot();
        deviceListBox.removeAllViews();
        int online = 0;
        if (devices.isEmpty()) {
            TextView tip = new TextView(this);
            tip.setText("启动管控服务后，已授权设备连接上来会显示在这里：型号、系统版本、处理器、电量等。");
            tip.setTextSize(13);
            tip.setTextColor(Color.parseColor("#8E8E93"));
            deviceListBox.addView(tip, matchWrap());
        }
        for (Map.Entry<String, JSONObject> e : devices.entrySet()) {
            final String id = e.getKey();
            JSONObject d = e.getValue();
            boolean isOnline = d.optBoolean("online", false);
            if (isOnline) online++;
            deviceListBox.addView(buildDeviceRow(id, d, isOnline), matchWrap());
        }
        summaryTv.setText("在线 " + online + " 台 · 已登记 " + devices.size() + " 台");
    }

    private View buildDeviceRow(final String deviceId, JSONObject d, boolean online) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(14), dp(10), dp(14), dp(10));
        row.setBackgroundColor(Color.parseColor(online ? "#F2F7F2" : "#F5F5F6"));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.topMargin = dp(8);
        row.setLayoutParams(rowLp);

        String model = d.optString("model", "未知型号");
        String manu = d.optString("manufacturer", "");
        TextView t1 = new TextView(this);
        t1.setText(model + (manu.length() > 0 ? "（" + manu + "）" : ""));
        t1.setTextSize(15);
        t1.setTextColor(Color.parseColor("#1C1C1E"));
        row.addView(t1, matchWrap());

        row.addView(line("系统：Android " + d.optString("release", "?")
                + "（API " + d.optInt("sdk", 0) + "）"), matchWrap());

        String cpu = d.optString("cpuHardware", "");
        if (cpu.length() == 0) cpu = d.optString("abi", "未知");
        row.addView(line("处理器：" + cpu + " · " + d.optInt("cores", 0) + " 核"), matchWrap());

        String bat = d.has("battery") ? (d.optInt("battery", -1) + "%") : "未知";
        row.addView(line("电量：" + bat + (d.optBoolean("charging", false) ? "（充电中）" : "")), matchWrap());

        StringBuilder extra = new StringBuilder();
        if (d.has("storageFreeGB")) extra.append("剩余空间 ")
                .append(String.format("%.1f", d.optDouble("storageFreeGB"))).append("GB");
        if (d.has("ramAvailGB")) {
            if (extra.length() > 0) extra.append(" · ");
            extra.append("可用内存 ").append(String.format("%.1f", d.optDouble("ramAvailGB"))).append("GB");
        }
        if (extra.length() > 0) row.addView(line(extra.toString()), matchWrap());

        row.addView(line("IP：" + d.optString("ip", "?") + " · 应用版本 " + d.optString("appVer", "?")
                + " · " + (online ? "在线" : "离线")), matchWrap());

        if (online) {
            Button kick = new Button(this);
            kick.setText("断开");
            kick.setTextSize(13);
            LinearLayout.LayoutParams blp = matchWrap();
            blp.topMargin = dp(6);
            kick.setLayoutParams(blp);
            kick.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    startServiceCompat(new Intent(MainActivity.this, ControlService.class)
                            .setAction(ControlService.ACTION_KICK)
                            .putExtra(ControlService.EXTRA_DEVICE_ID, deviceId));
                }
            });
            row.addView(kick);
        }
        return row;
    }

    private TextView line(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12);
        tv.setTextColor(Color.parseColor("#5A6270"));
        tv.setPadding(0, dp(2), 0, 0);
        return tv;
    }

    private void addSectionTitle(LinearLayout root, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setPadding(0, dp(4), 0, dp(10));
        root.addView(tv, matchWrap());
    }

    private void divider(LinearLayout root) {
        View v = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        lp.topMargin = dp(20);
        lp.bottomMargin = dp(16);
        v.setBackgroundColor(Color.parseColor("#E0E0E0"));
        root.addView(v, lp);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.rightMargin = dp(4);
        return lp;
    }
}
