package com.DL.devcontrol;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;

final class LanUtil {

    private LanUtil() { }

    /** 本机在当前 Wi-Fi 下的局域网 IP，取不到时返回提示文字 */
    static String localIp(Context ctx) {
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return "未知";
            WifiInfo info = wm.getConnectionInfo();
            if (info == null) return "未知";
            int ip = info.getIpAddress();
            if (ip == 0) return "未知（请确认已连接 Wi-Fi）";
            return String.format("%d.%d.%d.%d",
                    ip & 0xff, (ip >> 8) & 0xff, (ip >> 16) & 0xff, (ip >> 24) & 0xff);
        } catch (Throwable t) {
            return "未知";
        }
    }
}
