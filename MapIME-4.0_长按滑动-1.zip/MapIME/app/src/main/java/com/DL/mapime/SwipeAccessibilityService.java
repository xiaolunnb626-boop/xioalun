package com.DL.mapime;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.annotation.TargetApi;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

/**
 * 滚动辅助服务：悬浮按钮「长按后滑动」时，找到按钮位置下方可滚动的控件，
 * 对它执行无障碍滚动动作（按页滚动）。
 *
 * 两种方式配合：
 * 1) 手指还按着时：系统的无障碍输入过滤器会在收到真实触摸事件时取消注入手势，所以不能注入手势，
 *    只能用「无障碍滚动动作」（不走触摸事件，不会被取消）——对原生列表/网页有效，按页滚动；
 * 2) 手指抬起后：此时已没有真实触摸，可以用 dispatchGesture 把刚才的滑动轨迹重放到下方应用上，
 *    对游戏、自绘界面等不暴露滚动控件的应用也有效。
 */
public class SwipeAccessibilityService extends AccessibilityService {
    static volatile SwipeAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        if (instance == this) instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    /**
     * 手指抬起后，把滑动轨迹重放到下方应用（Android 7.0+）。
     *
     * @param pts        x0,y0,x1,y1,... 屏幕坐标
     * @param durationMs 重放总时长
     * @param done       手势完成或被取消时回调（主线程）
     * @return 是否已成功提交手势
     */
    @TargetApi(24)
    public boolean replay(float[] pts, long durationMs, final Runnable done) {
        if (Build.VERSION.SDK_INT < 24 || pts == null || pts.length < 4) return false;
        try {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            Path path = new Path();
            for (int i = 0; i + 1 < pts.length; i += 2) {
                float x = Math.max(0f, Math.min(dm.widthPixels - 1f, pts[i]));
                float y = Math.max(0f, Math.min(dm.heightPixels - 1f, pts[i + 1]));
                if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
            }
            long dur = Math.max(100L, Math.min(durationMs, 3000L));
            GestureDescription g = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, dur))
                    .build();
            return dispatchGesture(g, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) {
                    if (done != null) done.run();
                }
                @Override public void onCancelled(GestureDescription d) {
                    if (done != null) done.run();
                }
            }, new Handler(Looper.getMainLooper()));
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 在屏幕坐标 (x,y) 处找最内层的可滚动控件并滚动一页。
     * dx/dy 为手指滑动方向：手指向上滑(dy<0)=内容向下滚。
     *
     * @return 是否成功执行了滚动
     */
    public boolean scrollAt(int x, int y, float dx, float dy) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo target = findScrollable(root, x, y, 0);
        if (target == null) return false;

        boolean vertical = Math.abs(dy) >= Math.abs(dx);
        boolean ok = false;
        if (Build.VERSION.SDK_INT >= 23) {
            AccessibilityNodeInfo.AccessibilityAction act;
            if (vertical) {
                act = dy < 0 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN
                        : AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP;
            } else {
                act = dx < 0 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT
                        : AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT;
            }
            if (target.getActionList().contains(act)) {
                ok = target.performAction(act.getId());
            }
        }
        if (!ok) {
            // 没有方向性动作时退回到前进/后退
            boolean forward = vertical ? dy < 0 : dx < 0;
            ok = target.performAction(forward
                    ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
        }
        return ok;
    }

    /** 深度优先：返回包含 (x,y) 的最内层可滚动节点 */
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo node, int x, int y, int depth) {
        if (node == null || depth > 40) return null;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (!r.contains(x, y)) return null;
        AccessibilityNodeInfo best = null;
        int n = node.getChildCount();
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo hit = findScrollable(node.getChild(i), x, y, depth + 1);
            if (hit != null) best = hit;   // 后面的子节点在上层，覆盖前面的
        }
        if (best != null) return best;
        return node.isScrollable() ? node : null;
    }
}
