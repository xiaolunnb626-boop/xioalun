package com.DL.mapime;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 宏数据（由「高级底栏」通过 MacroProvider 同步过来，JSON 格式）：
 * {"up":"宏名","down":"宏名","macros":[{"name":"宏名","steps":[{"text":"A","delay":100}]}]}
 */
public class MacroStore {
    public static class Step {
        public final String text;
        public final long delay;
        Step(String text, long delay) {
            this.text = text;
            this.delay = delay < 0 ? 0 : delay;
        }
    }

    private static final String PREF = "macro_store";
    private static final String KEY = "json";

    private final SharedPreferences sp;

    public MacroStore(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void saveJson(String json) {
        sp.edit().putString(KEY, json == null ? "" : json).apply();
    }

    public String getJson() {
        return sp.getString(KEY, "");
    }

    private JSONObject root() {
        try {
            String s = getJson();
            if (s.length() == 0) return new JSONObject();
            return new JSONObject(s);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public String boundMacro(boolean up) {
        return root().optString(up ? "up" : "down", "");
    }

    public int macroCount() {
        JSONArray a = root().optJSONArray("macros");
        return a == null ? 0 : a.length();
    }

    public List<Step> steps(String macroName) {
        List<Step> out = new ArrayList<Step>();
        if (macroName == null || macroName.length() == 0) return out;
        JSONArray macros = root().optJSONArray("macros");
        if (macros == null) return out;
        for (int i = 0; i < macros.length(); i++) {
            JSONObject m = macros.optJSONObject(i);
            if (m == null || !macroName.equals(m.optString("name", ""))) continue;
            JSONArray steps = m.optJSONArray("steps");
            if (steps == null) return out;
            for (int j = 0; j < steps.length(); j++) {
                JSONObject s = steps.optJSONObject(j);
                if (s == null) continue;
                out.add(new Step(s.optString("text", ""), s.optLong("delay", 0L)));
            }
            return out;
        }
        return out;
    }
}
