package com.example.remotecontrol.control

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.*
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class MainActivity : Activity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseDatabase.getInstance().reference }
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var deviceId: EditText
    private lateinit var output: TextView
    private lateinit var feature: EditText
    private lateinit var parameter: EditText
    private lateinit var parameterValue: EditText
    private var statusListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        fun label(s: String) = TextView(this).apply { text = s; textSize = 16f }
        fun edit(hintText: String, secret: Boolean = false) = EditText(this).apply {
            hint = hintText
            if (secret) inputType = 129
        }
        fun button(text: String, action: () -> Unit) =
            Button(this).apply { this.text = text; setOnClickListener { action() } }
        email = edit("Firebase 邮箱")
        password = edit("密码", true)
        deviceId = edit("被控端 Device ID（需一致）")
        feature = edit("功能键名，例如 exampleFeature")
        parameter = edit("参数名，例如 refreshInterval")
        parameterValue = edit("参数值，例如 5000")
        output = label("尚未连接")
        root.addView(label("远程管控 · 管理端"))
        root.addView(email); root.addView(password)
        root.addView(button("登录 / 注册账号") { loginOrRegister() })
        root.addView(deviceId)
        root.addView(button("读取设备状态") { listenStatus() })
        root.addView(feature)
        root.addView(button("开启功能") { setFeature(true) })
        root.addView(button("关闭功能") { setFeature(false) })
        root.addView(parameter); root.addView(parameterValue)
        root.addView(button("更新参数（数字）") { setParameter() })
        root.addView(button("读取最近日志") { readLogs() })
        root.addView(output)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun loginOrRegister() {
        val e = email.text.toString().trim()
        val p = password.text.toString()
        if (e.isBlank() || p.length < 6) { show("请输入邮箱和至少 6 位密码"); return }
        auth.signInWithEmailAndPassword(e, p)
            .addOnSuccessListener { show("登录成功：${it.user?.uid}") }
            .addOnFailureListener {
                auth.createUserWithEmailAndPassword(e, p)
                    .addOnSuccessListener { show("注册成功：${it.user?.uid}") }
                    .addOnFailureListener { err -> show("登录/注册失败：${err.message}") }
            }
    }

    private fun deviceRef(): DatabaseReference? {
        val uid = auth.currentUser?.uid
        val id = deviceId.text.toString().trim()
        if (uid == null || id.isBlank()) { show("请先登录并填写 Device ID"); return null }
        return db.child("users").child(uid).child("devices").child(id)
    }

    private fun listenStatus() {
        val ref = deviceRef()?.child("status") ?: return
        statusListener?.let { ref.removeEventListener(it) }
        statusListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { show("设备状态：${s.value ?: "暂无数据"}") }
            override fun onCancelled(e: DatabaseError) { show("读取失败：${e.message}") }
        }
        ref.addValueEventListener(statusListener!!)
    }

    private fun setFeature(enabled: Boolean) {
        val name = feature.text.toString().trim()
        if (name.isBlank()) { show("请输入功能键名"); return }
        val ref = deviceRef()?.child("config")?.child("features")?.child(name) ?: return
        ref.setValue(mapOf("enabled" to enabled, "updatedAt" to ServerValue.TIMESTAMP))
            .addOnSuccessListener { show("已提交：$name = $enabled") }
            .addOnFailureListener { show("提交失败：${it.message}") }
    }

    private fun setParameter() {
        val name = parameter.text.toString().trim()
        val value = parameterValue.text.toString().trim().toLongOrNull()
        if (name.isBlank() || value == null) { show("请输入参数名和整数值"); return }
        val ref = deviceRef()?.child("config")?.child("parameters")?.child(name) ?: return
        ref.setValue(value).addOnSuccessListener { show("参数已提交：$name = $value") }
            .addOnFailureListener { show("提交失败：${it.message}") }
    }

    private fun readLogs() {
        val ref = deviceRef()?.child("logs") ?: return
        ref.limitToLast(30).get()
            .addOnSuccessListener { s ->
                val lines = s.children.map { it.value.toString() }
                show(if (lines.isEmpty()) "暂无日志" else lines.joinToString("\n"))
            }
            .addOnFailureListener { show("日志读取失败：${it.message}") }
    }

    private fun show(s: String) { runOnUiThread { output.text = s } }

    override fun onDestroy() {
        super.onDestroy()
        statusListener?.let { deviceRef()?.child("status")?.removeEventListener(it) }
    }
}
