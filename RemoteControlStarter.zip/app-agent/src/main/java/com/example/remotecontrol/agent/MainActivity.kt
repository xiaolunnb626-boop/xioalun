package com.example.remotecontrol.agent

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class MainActivity : Activity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseDatabase.getInstance().reference }
    private val deviceId by lazy {
        getSharedPreferences("agent", MODE_PRIVATE).let { prefs ->
            prefs.getString("deviceId", null) ?: java.util.UUID.randomUUID().toString()
                .also { prefs.edit().putString("deviceId", it).apply() }
        }
    }
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var output: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var featureListener: ValueEventListener? = null
    private var parameterListener: ValueEventListener? = null
    private val heartbeat = object : Runnable {
        override fun run() {
            if (auth.currentUser != null) {
                deviceRef()?.child("status")?.updateChildren(
                    mapOf("online" to true, "appVersion" to "1.0",
                        "deviceId" to deviceId, "lastSeen" to ServerValue.TIMESTAMP)
                )
            }
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val root = LinearLayout(this).apply { orientation = 1; setPadding(24,24,24,24) }
        email = EditText(this).apply { hint = "与管理端相同的 Firebase 邮箱" }
        password = EditText(this).apply { hint = "密码"; inputType = 129 }
        output = TextView(this).apply { textSize = 15f }
        root.addView(TextView(this).apply { text = "远程管控 · 被控端"; textSize = 22f })
        root.addView(TextView(this).apply { text = "Device ID：$deviceId" })
        root.addView(email); root.addView(password)
        root.addView(Button(this).apply {
            text = "登录 / 注册并启动监听"
            setOnClickListener { signInOrRegister() }
        })
        root.addView(output)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun signInOrRegister() {
        val e = email.text.toString().trim()
        val p = password.text.toString()
        if (e.isBlank() || p.length < 6) { show("请输入邮箱和至少 6 位密码"); return }
        auth.signInWithEmailAndPassword(e, p)
            .addOnSuccessListener { startAgent() }
            .addOnFailureListener {
                auth.createUserWithEmailAndPassword(e, p)
                    .addOnSuccessListener { startAgent() }
                    .addOnFailureListener { err -> show("登录/注册失败：${err.message}") }
            }
    }

    private fun deviceRef(): DatabaseReference? {
        val uid = auth.currentUser?.uid ?: return null
        return db.child("users").child(uid).child("devices").child(deviceId)
    }

    private fun startAgent() {
        val ref = deviceRef() ?: return
        ref.child("status").updateChildren(
            mapOf("online" to true, "appVersion" to "1.0",
                "deviceId" to deviceId, "lastSeen" to ServerValue.TIMESTAMP)
        )
        featureListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val changes = mutableListOf<String>()
                for (child in s.children) {
                    val name = child.key ?: continue
                    // 只允许明确列出的示例功能，接入现有业务时在这里调用实际开关。
                    if (name == "exampleFeature") {
                        val enabled = child.child("enabled").getValue(Boolean::class.java) ?: false
                        changes.add("$name = $enabled")
                    }
                }
                if (changes.isNotEmpty()) {
                    log("INFO", "收到功能配置：" + changes.joinToString())
                    show(changes.joinToString("\n"))
                }
            }
            override fun onCancelled(e: DatabaseError) { show("功能监听失败：${e.message}") }
        }
        ref.child("config").child("features").addValueEventListener(featureListener!!)

        parameterListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val interval = s.child("refreshInterval").getValue(Long::class.java)
                if (interval != null && interval in 1000L..60000L) {
                    log("INFO", "refreshInterval 更新为 $interval")
                    show("参数已接收：refreshInterval=$interval")
                }
            }
            override fun onCancelled(e: DatabaseError) { show("参数监听失败：${e.message}") }
        }
        ref.child("config").child("parameters").addValueEventListener(parameterListener!!)
        handler.removeCallbacks(heartbeat)
        handler.post(heartbeat)
        log("INFO", "被控端已启动，设备 ID：$deviceId")
        show("已连接。请在管理端填入此 Device ID：\n$deviceId")
    }

    private fun log(level: String, message: String) {
        val entry = mapOf("timestamp" to ServerValue.TIMESTAMP,
            "level" to level, "message" to message.take(1000))
        deviceRef()?.child("logs")?.push()?.setValue(entry)
    }

    private fun show(s: String) { runOnUiThread { output.text = s } }

    override fun onResume() {
        super.onResume()
        if (auth.currentUser != null) handler.post(heartbeat)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(heartbeat)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(heartbeat)
        deviceRef()?.let { ref ->
            featureListener?.let { ref.child("config").child("features").removeEventListener(it) }
            parameterListener?.let { ref.child("config").child("parameters").removeEventListener(it) }
        }
    }
}
