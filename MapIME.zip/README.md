# RemoteControlStarter

两个 Android APK 的起步工程：
- `app-control`：管理端示例，可登录 Firebase、填写设备 ID、写入功能开关/参数、查看状态和日志。
- `app-agent`：被控端示例，可登录 Firebase、上报状态、监听配置、把允许的配置写入日志并显示在屏幕上。

## 环境
- Android Studio（建议使用支持 AGP 8.10.1 的版本）
- JDK 17
- Firebase 项目和 Realtime Database
- 两个不同的 Android applicationId

## 配置步骤
1. 在 Firebase Console 创建项目。
2. 在 Authentication 中启用 Email/Password。
3. 创建 Realtime Database。
4. 注册两个 Android 应用：
   - `com.example.remotecontrol.control`
   - `com.example.remotecontrol.agent`
5. 分别下载 `google-services.json`，放入 `app-control/` 和 `app-agent/`。
6. 在 Firebase Realtime Database Rules 中先使用 README 下方的测试规则，仅用于你自己的测试设备。
7. Android Studio 打开此目录，Sync Gradle。
8. 分别运行 `app-agent` 和 `app-control`。

## 数据路径
`users/{uid}/devices/{deviceId}/status`
`users/{uid}/devices/{deviceId}/config/features/{featureName}`
`users/{uid}/devices/{deviceId}/config/parameters/{parameterName}`
`users/{uid}/devices/{deviceId}/logs/{pushId}`

## 重要限制
这是可扩展的起步工程，不是生产级远程管理系统。当前示例用同一 Firebase 登录 UID 访问自己的数据，便于双机联调；正式使用前必须实现管理端/被控端角色分离、设备配对授权、服务端校验和严格数据库规则。不要用它来绕过 Android 系统权限或控制未经授权的设备。

Android 进程可能被系统终止，数据库监听不能保证应用被杀死后仍实时执行。心跳示例只在 Activity 前台运行期间更新。不要将管理员服务账号密钥放入 APK。

## 手机云端编译（无需 Android Studio）
1. 在 GitHub 网页创建一个空仓库。
2. 将此 ZIP 解压后，把里面的所有文件和 `.github` 隐藏文件夹上传到仓库根目录（网页上传时需确认 `.github/workflows/build.yml` 确实被提交）。
3. 打开仓库的 Actions 页面，运行 `Build Android APKs`。
4. 完成后进入该次运行页面底部的 Artifacts，下载 `RemoteControl-debug-APKs`。
5. 若没有放入真实 Firebase 配置，工作流会使用占位配置来尝试编译。这样的 APK 仅用于安装/界面测试，无法连接真实 Firebase；要启用远程功能，必须将两个真实 `google-services.json` 放入各自模块后重新构建。

工作流编译的是 debug APK，仅供个人测试，不是已验证的生产版本。
