package com.DL.mapime;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** 「映射」输入法：激活且有输入框时，按绑定的音量键执行宏（逐步 commitText + 毫秒延迟）。 */
public class MapInputMethodService extends InputMethodService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean consumingVolume = false;
    private long runToken = 0L;
    private MacroStore store;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        store = new MacroStore(this);
    }

    @Override
    public boolean onEvaluateInputViewShown() {
        return true;
    }

    @Override
    public View onCreateInputView() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(8), dp(16), dp(8));
        bar.setMinimumHeight(dp(60));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(235, 245, 245, 247));
        bg.setStroke(dp(1), Color.argb(60, 0, 0, 0));
        bar.setBackground(bg);

        TextView tip = new TextView(this);
        tip.setText("映射已启用 · 音量键触发宏");
        tip.setTextSize(14);
        tip.setTextColor(Color.rgb(28, 28, 30));
        bar.addView(tip, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView switcher = new TextView(this);
        switcher.setText("切换输入法");
        switcher.setTextSize(14);
        switcher.setTextColor(Color.rgb(0, 122, 255));
        switcher.setGravity(Gravity.CENTER);
        switcher.setPadding(dp(14), 0, dp(14), 0);
        GradientDrawable btn = new GradientDrawable();
        btn.setCornerRadius(dp(14));
        btn.setColor(Color.argb(40, 0, 122, 255));
        btn.setStroke(dp(1), Color.argb(130, 0, 122, 255));
        switcher.setBackground(btn);
        switcher.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        });
        bar.addView(switcher, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)));
        return bar;
    }

    private void runMacro(String name) {
        List<MacroStore.Step> steps = store.steps(name);
        if (steps.isEmpty()) return;
        long token = ++runToken;
        runStep(steps, 0, token);
    }

    private void runStep(final List<MacroStore.Step> steps, final int index, final long token) {
        if (token != runToken || index >= steps.size()) return;
        MacroStore.Step s = steps.get(index);

        InputConnection ic = getCurrentInputConnection();
        if (ic != null && s.text.length() > 0) {
            ic.commitText(s.text, 1);
        }
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                runStep(steps, index + 1, token);
            }
        }, s.delay);
    }

    private boolean handleVolume(int keyCode, KeyEvent event) {
        if (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false;
        }
        String macro = store.boundMacro(keyCode == KeyEvent.KEYCODE_VOLUME_UP);
        if (macro == null || macro.length() == 0) return false;
        consumingVolume = true;
        if (event == null || event.getRepeatCount() == 0) runMacro(macro);
        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (handleVolume(keyCode, event)) return true;
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                && consumingVolume) {
            consumingVolume = false;
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onFinishInput() {
        ++runToken;
        super.onFinishInput();
    }

    @Override
    public void onDestroy() {
        ++runToken;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
