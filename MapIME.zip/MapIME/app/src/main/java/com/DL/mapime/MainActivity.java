package com.DL.mapime;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 设置页：启用输入法、呼出系统选择器、查看宏同步状态。 */
public class MainActivity extends Activity {
    private TextView status;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(48), dp(24), dp(24));

        TextView title = new TextView(this);
        title.setText("映射输入法");
        title.setTextSize(28);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(15);
        status.setPadding(0, dp(16), 0, dp(24));
        root.addView(status);

        Button enable = new Button(this);
        enable.setText("① 在系统设置里启用「映射」");
        enable.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        });
        root.addView(enable);

        Button pick = new Button(this);
        pick.setText("② 呼出输入法选择器");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                        .showInputMethodPicker();
            }
        });
        root.addView(pick);

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        boolean enabled = false;
        for (InputMethodInfo i : imm.getEnabledInputMethodList()) {
            if (i.getPackageName().equals(getPackageName())) enabled = true;
        }
        MacroStore store = new MacroStore(this);
        String ver = "?";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) { }
        status.setText("版本：" + ver + "\n输入法状态：" + (enabled ? "已启用" : "未启用")
                + "\n已同步宏：" + store.macroCount() + " 个"
                + "\n音量+ → " + show(store.boundMacro(true))
                + "\n音量- → " + show(store.boundMacro(false)));
    }

    private String show(String s) {
        return (s == null || s.length() == 0) ? "未绑定" : s;
    }
}
