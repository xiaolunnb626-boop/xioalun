package com.DL.mapime;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 诊断日志：把「穿透监听」等功能的关键步骤记下来，在映射输入法 App 首页查看（方便截图反馈问题）。 */
final class DiagLog {
    private static final String PREF = "diag";
    private static final String KEY = "log";
    private static final int MAX_LINES = 60;

    private DiagLog() { }

    static synchronized void add(Context ctx, String msg) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            String old = sp.getString(KEY, "");
            String line = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + " " + msg;
            String[] lines = old.length() == 0 ? new String[0] : old.split("\n");
            StringBuilder sb = new StringBuilder();
            int start = Math.max(0, lines.length - (MAX_LINES - 1));
            for (int i = start; i < lines.length; i++) sb.append(lines[i]).append('\n');
            sb.append(line);
            sp.edit().putString(KEY, sb.toString()).apply();
        } catch (Throwable ignored) { }
    }

    static String read(Context ctx) {
        try {
            String s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "");
            return s.length() == 0 ? "（还没有记录）" : s;
        } catch (Throwable t) {
            return "（读取失败）";
        }
    }

    static void clear(Context ctx) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
        } catch (Throwable ignored) { }
    }
}
