package com.DL.mapime;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuBinderWrapper;
import rikka.shizuku.SystemServiceHelper;

/**
 * 通过 Shizuku（ADB 级权限，不需要 root）把触摸事件注入系统。
 * 长按悬浮按钮后滑动时，用它在按钮下方的应用上「再按一根手指」跟着滑，下方应用就能实时跟手。
 *
 * 触摸事件用虚拟设备(deviceId=-1)注入，与真实手指的触摸流相互独立。
 */
final class ShizukuInjector {
    static final int REQ_CODE = 7001;
    /**
     * 注入的手指使用的「指针编号」。真实手指的编号从 0 开始依次分配，注入的如果也用 0，
     * 游戏会以为是你左手那根手指又按下/抬起了，移动键就被打断；所以用一个不会冲突的大编号。
     */
    static final int POINTER_ID = 20;

    private static Object inputManager;     // android.hardware.input.IInputManager（经 Shizuku 的 Binder）
    private static Method injectMethod;
    private static int injectArgc;
    private static boolean bypassTried;
    static volatile String lastError = "";   // 最近一次失败的原因

    private ShizukuInjector() { }

    /** Shizuku 服务是否在运行 */
    static boolean isRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    /** 是否已授权给本应用 */
    static boolean hasPermission() {
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 弹出 Shizuku 的授权对话框 */
    static void requestPermission() {
        try {
            Shizuku.requestPermission(REQ_CODE);
        } catch (Throwable t) {
            lastError = String.valueOf(t);
        }
    }

    /** 经典的「双重反射」解除隐藏 API 限制（失败也没关系，直接反射 IInputManager 在多数系统上也可用） */
    private static void tryHiddenApiExemption() {
        try {
            Method forName = Class.class.getDeclaredMethod("forName", String.class);
            Method getDeclaredMethod = Class.class.getDeclaredMethod("getDeclaredMethod", String.class, Class[].class);
            Class<?> vmRuntimeClass = (Class<?>) forName.invoke(null, "dalvik.system.VMRuntime");
            Method getRuntime = (Method) getDeclaredMethod.invoke(vmRuntimeClass, "getRuntime", null);
            Method setExemptions = (Method) getDeclaredMethod.invoke(vmRuntimeClass,
                    "setHiddenApiExemptions", new Class[]{String[].class});
            Object vmRuntime = getRuntime.invoke(null);
            setExemptions.invoke(vmRuntime, new Object[]{new String[]{"L"}});
        } catch (Throwable ignored) { }
    }

    /** 取得 IInputManager 并找到 injectInputEvent 方法 */
    static synchronized boolean prepare() {
        if (inputManager != null && injectMethod != null) {
            if (isRunning()) return true;
            inputManager = null;
            injectMethod = null;
        }
        try {
            if (!bypassTried) {
                bypassTried = true;
                if (Build.VERSION.SDK_INT >= 28) tryHiddenApiExemption();
            }
            IBinder base = SystemServiceHelper.getSystemService(Context.INPUT_SERVICE);
            if (base == null) {
                lastError = "获取 input 服务失败";
                return false;
            }
            IBinder wrapped = new ShizukuBinderWrapper(base);
            Class<?> stub = Class.forName("android.hardware.input.IInputManager$Stub");
            Object im = stub.getMethod("asInterface", IBinder.class).invoke(null, wrapped);
            Class<?> iface = Class.forName("android.hardware.input.IInputManager");
            Method m;
            int argc;
            try {
                m = iface.getMethod("injectInputEvent", InputEvent.class, int.class);
                argc = 2;
            } catch (NoSuchMethodException e) {
                m = iface.getMethod("injectInputEvent", InputEvent.class, int.class, int.class);
                argc = 3;
            }
            inputManager = im;
            injectMethod = m;
            injectArgc = argc;
            return true;
        } catch (Throwable t) {
            lastError = String.valueOf(t);
            return false;
        }
    }

    /** 注入一个单指触摸事件（异步，不等待结果） */
    static boolean inject(int action, float x, float y, long downTime) {
        return inject(action, x, y, downTime, false);
    }

    /**
     * 注入一个单指触摸事件（屏幕坐标）。
     * waitResult=true 时等待系统返回「是否被接受」（INJECT_INPUT_EVENT_MODE_WAIT_FOR_RESULT），
     * 被系统直接丢弃（例如不允许两路触摸同时进行）时返回 false。
     */
    static boolean inject(int action, float x, float y, long downTime, boolean waitResult) {
        MotionEvent ev = null;
        try {
            long now = SystemClock.uptimeMillis();
            MotionEvent.PointerProperties[] props = new MotionEvent.PointerProperties[1];
            props[0] = new MotionEvent.PointerProperties();
            props[0].id = POINTER_ID;
            props[0].toolType = MotionEvent.TOOL_TYPE_FINGER;
            MotionEvent.PointerCoords[] coords = new MotionEvent.PointerCoords[1];
            coords[0] = new MotionEvent.PointerCoords();
            coords[0].x = x;
            coords[0].y = y;
            coords[0].pressure = 1.0f;
            coords[0].size = 1.0f;
            ev = MotionEvent.obtain(downTime, now, action, 1, props, coords,
                    0, 0, 1.0f, 1.0f, -1, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
            int mode = waitResult ? 1 : 0;      // 1=WAIT_FOR_RESULT, 0=ASYNC
            Object r;
            if (injectArgc == 2) {
                r = injectMethod.invoke(inputManager, ev, mode);
            } else {
                r = injectMethod.invoke(inputManager, ev, mode, -1);
            }
            boolean ok = !(r instanceof Boolean) || ((Boolean) r).booleanValue();
            if (!ok) lastError = "系统拒绝了这次注入（返回 false）";
            return ok;
        } catch (Throwable t) {
            lastError = String.valueOf(t);
            return false;
        } finally {
            if (ev != null) ev.recycle();
        }
    }
}
