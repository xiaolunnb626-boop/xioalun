package com.DL.mapime;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuBinderWrapper;
import rikka.shizuku.SystemServiceHelper;

/**
 * 通过 Shizuku（ADB 级权限，不需要 root）把触摸事件注入系统。
 * 长按悬浮按钮后滑动时，用它在按钮下方的应用上「再按一根手指」跟着滑，下方应用就能实时跟手。
 *
 * 触摸事件用虚拟设备(deviceId=-1)注入，与真实手指的触摸流相互独立。
 */
final class ShizukuInjector {
    static final int REQ_CODE = 7001;

    private static Object inputManager;     // android.hardware.input.IInputManager（经 Shizuku 的 Binder）
    private static Method injectMethod;
    private static int injectArgc;
    private static boolean bypassTried;
    static volatile String lastError = "";

    private ShizukuInjector() { }

    /** Shizuku 服务是否在运行 */
    static boolean isRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    /** 是否已授权给本应用 */
    static boolean hasPermission() {
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 弹出 Shizuku 的授权对话框 */
    static void requestPermission() {
        try {
            Shizuku.requestPermission(REQ_CODE);
        } catch (Throwable t) {
            lastError = String.valueOf(t);
        }
    }

    /** 经典的「双重反射」解除隐藏 API 限制（失败也没关系，直接反射 IInputManager 在多数系统上也可用） */
    private static void tryHiddenApiExemption() {
        try {
            Method forName = Class.class.getDeclaredMethod("forName", String.class);
            Method getDeclaredMethod = Class.class.getDeclaredMethod("getDeclaredMethod", String.class, Class[].class);
            Class<?> vmRuntimeClass = (Class<?>) forName.invoke(null, "dalvik.system.VMRuntime");
            Method getRuntime = (Method) getDeclaredMethod.invoke(vmRuntimeClass, "getRuntime", null);
            Method setExemptions = (Method) getDeclaredMethod.invoke(vmRuntimeClass,
                    "setHiddenApiExemptions", new Class[]{String[].class});
            Object vmRuntime = getRuntime.invoke(null);
            setExemptions.invoke(vmRuntime, new Object[]{new String[]{"L"}});
        } catch (Throwable ignored) { }
    }

    /** 取得 IInputManager 并找到 injectInputEvent 方法 */
    static synchronized boolean prepare() {
        if (inputManager != null && injectMethod != null) {
            if (isRunning()) return true;
            inputManager = null;
            injectMethod = null;
        }
        try {
            if (!bypassTried) {
                bypassTried = true;
                if (Build.VERSION.SDK_INT >= 28) tryHiddenApiExemption();
            }
            IBinder base = SystemServiceHelper.getSystemService(Context.INPUT_SERVICE);
            if (base == null) {
                lastError = "获取 input 服务失败";
                return false;
            }
            IBinder wrapped = new ShizukuBinderWrapper(base);
            Class<?> stub = Class.forName("android.hardware.input.IInputManager$Stub");
            Object im = stub.getMethod("asInterface", IBinder.class).invoke(null, wrapped);
            Class<?> iface = Class.forName("android.hardware.input.IInputManager");
            Method m;
            int argc;
            try {
                m = iface.getMethod("injectInputEvent", InputEvent.class, int.class);
                argc = 2;
            } catch (NoSuchMethodException e) {
                m = iface.getMethod("injectInputEvent", InputEvent.class, int.class, int.class);
                argc = 3;
            }
            inputManager = im;
            injectMethod = m;
            injectArgc = argc;
            return true;
        } catch (Throwable t) {
            lastError = String.valueOf(t);
            return false;
        }
    }

    /** 注入一个单指触摸事件（屏幕坐标） */
    static boolean inject(int action, float x, float y, long downTime) {
        MotionEvent ev = null;
        try {
            long now = SystemClock.uptimeMillis();
            ev = MotionEvent.obtain(downTime, now, action, x, y, 1.0f, 1.0f, 0, 1.0f, 1.0f, -1, 0);
            ev.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            Object r;
            if (injectArgc == 2) {
                r = injectMethod.invoke(inputManager, ev, 0);          // INJECT_INPUT_EVENT_MODE_ASYNC
            } else {
                r = injectMethod.invoke(inputManager, ev, 0, -1);
            }
            return !(r instanceof Boolean) || ((Boolean) r).booleanValue();
        } catch (Throwable t) {
            lastError = String.valueOf(t);
            return false;
        } finally {
            if (ev != null) ev.recycle();
        }
    }
}
