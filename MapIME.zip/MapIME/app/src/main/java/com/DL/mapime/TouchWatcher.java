package com.DL.mapime;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

/**
 * 通过 Shizuku（ADB 级权限）运行 getevent，只「读取」触摸屏的原始触摸事件。
 * 触摸不会被拦截，手指仍然直接落在游戏等下方应用上（对游戏来说就是一根真实的手指），
 * 本类只是旁观：告诉悬浮按钮「有手指按在哪里、什么时候抬起」。
 */
final class TouchWatcher {

    interface Listener {
        void onDown(int id, int rawX, int rawY);
        void onMove(int id, int rawX, int rawY);
        void onUp(int id);
        void onError(String msg);
        void onInfo(String msg);
    }

    /** 触摸屏原始坐标的最大值（getevent -p 读出），用于换算到屏幕坐标 */
    static volatile int rawMaxX = 1;
    static volatile int rawMaxY = 1;

    private static final int SLOTS = 16;
    private static final int EV_SYN = 0, EV_ABS = 3;
    private static final int ABS_MT_SLOT = 0x2f, ABS_MT_POSITION_X = 0x35,
            ABS_MT_POSITION_Y = 0x36, ABS_MT_TRACKING_ID = 0x39;
    private static final Pattern MAX_PATTERN = Pattern.compile("max\\s+(\\d+)");

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Listener listener;
    private volatile boolean running;
    private Process process;

    TouchWatcher(Listener listener) {
        this.listener = listener;
    }

    synchronized void start() {
        if (running) return;
        running = true;
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                loop();
            }
        }, "TouchWatcher");
        t.setDaemon(true);
        t.start();
    }

    synchronized void stop() {
        running = false;
        try {
            if (process != null) process.destroy();
        } catch (Throwable ignored) { }
        process = null;
    }

    private void info(final String msg) {
        main.post(new Runnable() {
            @Override public void run() {
                if (running) listener.onInfo(msg);
            }
        });
    }

    private void error(final String msg) {
        if (!running) return;
        main.post(new Runnable() {
            @Override public void run() {
                listener.onError(msg);
            }
        });
    }

    /** Shizuku.newProcess 在新版本里不是公开接口，用反射调用 */
    private static Process newProcess(String[] cmd) throws Exception {
        Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        return (Process) m.invoke(null, cmd, null, null);
    }

    private static int parseMax(String line) {
        Matcher m = MAX_PATTERN.matcher(line);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    /** 找到触摸屏设备：同时有 ABS_MT_POSITION_X / Y，优先带 INPUT_PROP_DIRECT 的 */
    private String findTouchDevice() throws Exception {
        Process p = newProcess(new String[]{"getevent", "-pl"});
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        String cur = null;
        int mx = -1, my = -1;
        boolean direct = false;
        String best = null;
        int bx = 0, by = 0;
        boolean bestDirect = false;
        while ((line = r.readLine()) != null) {
            line = line.trim();
            if (line.startsWith("add device")) {
                if (cur != null && mx > 0 && my > 0 && (best == null || (direct && !bestDirect))) {
                    best = cur; bx = mx; by = my; bestDirect = direct;
                }
                int i = line.indexOf("/dev/input/");
                cur = i >= 0 ? line.substring(i).trim() : null;
                mx = -1;
                my = -1;
                direct = false;
            } else if (line.contains("ABS_MT_POSITION_X")) {
                mx = parseMax(line);
            } else if (line.contains("ABS_MT_POSITION_Y")) {
                my = parseMax(line);
            } else if (line.contains("INPUT_PROP_DIRECT")) {
                direct = true;
            }
        }
        if (cur != null && mx > 0 && my > 0 && (best == null || (direct && !bestDirect))) {
            best = cur; bx = mx; by = my;
        }
        try {
            p.destroy();
        } catch (Throwable ignored) { }
        if (best != null) {
            rawMaxX = bx;
            rawMaxY = by;
        }
        return best;
    }

    private static int hex(String s) {
        try {
            return (int) Long.parseLong(s, 16);
        } catch (Exception e) {
            return 0;
        }
    }

    private void postEvent(final int kind, final int id, final int x, final int y) {
        main.post(new Runnable() {
            @Override public void run() {
                if (!running) return;
                if (kind == 0) listener.onDown(id, x, y);
                else if (kind == 1) listener.onMove(id, x, y);
                else listener.onUp(id);
            }
        });
    }

    /**
     * 用 cat 读取 /dev/input/eventX 的二进制 input_event。
     * 不用 getevent：它往管道输出时会被缓冲，事件会延迟很久；cat 读到多少写多少，没有缓冲。
     */
    private void loop() {
        try {
            String dev = findTouchDevice();
            if (dev == null) {
                error("没有找到触摸屏设备");
                return;
            }
            final int recSize = (Build.SUPPORTED_64_BIT_ABIS != null
                    && Build.SUPPORTED_64_BIT_ABIS.length > 0) ? 24 : 16;
            Process p = newProcess(new String[]{"cat", dev});
            synchronized (this) {
                if (!running) {
                    p.destroy();
                    return;
                }
                process = p;
            }
            info("穿透监听已启动：" + dev + "（范围 " + (rawMaxX + 1) + "×" + (rawMaxY + 1) + "）");
            InputStream in = p.getInputStream();
            byte[] rec = new byte[recSize];
            ByteBuffer bb = ByteBuffer.wrap(rec).order(ByteOrder.LITTLE_ENDIAN);

            int[] xs = new int[SLOTS];
            int[] ys = new int[SLOTS];
            boolean[] active = new boolean[SLOTS];
            boolean[] downFlag = new boolean[SLOTS];
            boolean[] upFlag = new boolean[SLOTS];
            boolean[] dirty = new boolean[SLOTS];
            int slot = 0;
            int dbg = 0;

            while (running) {
                int off = 0;
                while (off < recSize) {
                    int n = in.read(rec, off, recSize - off);
                    if (n < 0) {
                        if (running) error("读取触摸事件的进程已结束");
                        return;
                    }
                    off += n;
                }
                int type = bb.getShort(recSize - 8) & 0xffff;
                int code = bb.getShort(recSize - 6) & 0xffff;
                int value = bb.getInt(recSize - 4);
                if (type == EV_ABS) {
                    if (code == ABS_MT_SLOT) {
                        slot = Math.max(0, Math.min(SLOTS - 1, value));
                    } else if (code == ABS_MT_TRACKING_ID) {
                        if (value == -1) upFlag[slot] = true;
                        else downFlag[slot] = true;
                    } else if (code == ABS_MT_POSITION_X) {
                        xs[slot] = value;
                        dirty[slot] = true;
                    } else if (code == ABS_MT_POSITION_Y) {
                        ys[slot] = value;
                        dirty[slot] = true;
                    }
                } else if (type == EV_SYN && code == 0) {
                    for (int s = 0; s < SLOTS; s++) {
                        if (downFlag[s]) {
                            active[s] = true;
                            if (dbg < 3) {
                                dbg++;
                                info("监听到手指按下：原始坐标 (" + xs[s] + "," + ys[s] + ")");
                            }
                            postEvent(0, s, xs[s], ys[s]);
                        } else if (upFlag[s]) {
                            if (active[s]) postEvent(2, s, 0, 0);
                            active[s] = false;
                        } else if (dirty[s] && active[s]) {
                            postEvent(1, s, xs[s], ys[s]);
                        }
                        downFlag[s] = false;
                        upFlag[s] = false;
                        dirty[s] = false;
                    }
                }
            }
        } catch (Throwable t) {
            error(String.valueOf(t));
        }
    }
}
