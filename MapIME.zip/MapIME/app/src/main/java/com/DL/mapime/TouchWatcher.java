package com.DL.mapime;

import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

/**
 * 通过 Shizuku（ADB 级权限）运行 getevent，只「读取」触摸屏的原始触摸事件。
 * 触摸不会被拦截，手指仍然直接落在游戏等下方应用上（对游戏来说就是一根真实的手指），
 * 本类只是旁观：告诉悬浮按钮「有手指按在哪里、什么时候抬起」。
 */
final class TouchWatcher {

    interface Listener {
        void onDown(int id, int rawX, int rawY);
        void onMove(int id, int rawX, int rawY);
        void onUp(int id);
        void onError(String msg);
    }

    /** 触摸屏原始坐标的最大值（getevent -p 读出），用于换算到屏幕坐标 */
    static volatile int rawMaxX = 1;
    static volatile int rawMaxY = 1;

    private static final int SLOTS = 16;
    private static final Pattern MAX_PATTERN = Pattern.compile("max\\s+(\\d+)");

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Listener listener;
    private volatile boolean running;
    private Process process;

    TouchWatcher(Listener listener) {
        this.listener = listener;
    }

    synchronized void start() {
        if (running) return;
        running = true;
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                loop();
            }
        }, "TouchWatcher");
        t.setDaemon(true);
        t.start();
    }

    synchronized void stop() {
        running = false;
        try {
            if (process != null) process.destroy();
        } catch (Throwable ignored) { }
        process = null;
    }

    private void error(final String msg) {
        if (!running) return;
        main.post(new Runnable() {
            @Override public void run() {
                listener.onError(msg);
            }
        });
    }

    /** Shizuku.newProcess 在新版本里不是公开接口，用反射调用 */
    private static Process newProcess(String[] cmd) throws Exception {
        Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        return (Process) m.invoke(null, cmd, null, null);
    }

    private static int parseMax(String line) {
        Matcher m = MAX_PATTERN.matcher(line);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    /** 找到触摸屏设备：同时有 ABS_MT_POSITION_X / Y，优先带 INPUT_PROP_DIRECT 的 */
    private String findTouchDevice() throws Exception {
        Process p = newProcess(new String[]{"getevent", "-pl"});
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        String cur = null;
        int mx = -1, my = -1;
        boolean direct = false;
        String best = null;
        int bx = 0, by = 0;
        boolean bestDirect = false;
        while ((line = r.readLine()) != null) {
            line = line.trim();
            if (line.startsWith("add device")) {
                if (cur != null && mx > 0 && my > 0 && (best == null || (direct && !bestDirect))) {
                    best = cur; bx = mx; by = my; bestDirect = direct;
                }
                int i = line.indexOf("/dev/input/");
                cur = i >= 0 ? line.substring(i).trim() : null;
                mx = -1;
                my = -1;
                direct = false;
            } else if (line.contains("ABS_MT_POSITION_X")) {
                mx = parseMax(line);
            } else if (line.contains("ABS_MT_POSITION_Y")) {
                my = parseMax(line);
            } else if (line.contains("INPUT_PROP_DIRECT")) {
                direct = true;
            }
        }
        if (cur != null && mx > 0 && my > 0 && (best == null || (direct && !bestDirect))) {
            best = cur; bx = mx; by = my;
        }
        try {
            p.destroy();
        } catch (Throwable ignored) { }
        if (best != null) {
            rawMaxX = bx;
            rawMaxY = by;
        }
        return best;
    }

    private static int hex(String s) {
        try {
            return (int) Long.parseLong(s, 16);
        } catch (Exception e) {
            return 0;
        }
    }

    private void postEvent(final int kind, final int id, final int x, final int y) {
        main.post(new Runnable() {
            @Override public void run() {
                if (!running) return;
                if (kind == 0) listener.onDown(id, x, y);
                else if (kind == 1) listener.onMove(id, x, y);
                else listener.onUp(id);
            }
        });
    }

    private void loop() {
        try {
            String dev = findTouchDevice();
            if (dev == null) {
                error("没有找到触摸屏设备");
                return;
            }
            Process p = newProcess(new String[]{"getevent", "-l", dev});
            synchronized (this) {
                if (!running) {
                    p.destroy();
                    return;
                }
                process = p;
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()), 8192);

            int[] xs = new int[SLOTS];
            int[] ys = new int[SLOTS];
            boolean[] active = new boolean[SLOTS];
            boolean[] downFlag = new boolean[SLOTS];
            boolean[] upFlag = new boolean[SLOTS];
            boolean[] dirty = new boolean[SLOTS];
            int slot = 0;

            String line;
            while (running && (line = br.readLine()) != null) {
                String[] t = line.trim().split("\\s+");
                int k = -1;
                for (int i = 0; i < t.length; i++) {
                    if (t[i].startsWith("EV_")) {
                        k = i;
                        break;
                    }
                }
                if (k < 0 || k + 2 >= t.length) continue;
                String type = t[k], code = t[k + 1], val = t[k + 2];
                if (type.equals("EV_ABS")) {
                    if (code.equals("ABS_MT_SLOT")) {
                        slot = Math.max(0, Math.min(SLOTS - 1, hex(val)));
                    } else if (code.equals("ABS_MT_TRACKING_ID")) {
                        if (val.equalsIgnoreCase("ffffffff")) upFlag[slot] = true;
                        else downFlag[slot] = true;
                    } else if (code.equals("ABS_MT_POSITION_X")) {
                        xs[slot] = hex(val);
                        dirty[slot] = true;
                    } else if (code.equals("ABS_MT_POSITION_Y")) {
                        ys[slot] = hex(val);
                        dirty[slot] = true;
                    }
                } else if (type.equals("EV_SYN") && code.equals("SYN_REPORT")) {
                    for (int s = 0; s < SLOTS; s++) {
                        if (downFlag[s]) {
                            active[s] = true;
                            postEvent(0, s, xs[s], ys[s]);
                        } else if (upFlag[s]) {
                            if (active[s]) postEvent(2, s, 0, 0);
                            active[s] = false;
                        } else if (dirty[s] && active[s]) {
                            postEvent(1, s, xs[s], ys[s]);
                        }
                        downFlag[s] = false;
                        upFlag[s] = false;
                        dirty[s] = false;
                    }
                }
            }
            if (running) error("getevent 已结束");
        } catch (Throwable t) {
            error(String.valueOf(t));
        }
    }
}
