package com.DL.mapime;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 悬浮按钮服务：
 *   长按按钮 —— 通过「映射」输入法循环输入宏里的字母，松手停止；
 *   点一下   —— 只输入一遍；
 *   拖动     —— 移动按钮位置。
 */
public class FloatService extends Service {
    private static final String CHANNEL = "float_btn";
    private static final long LONG_PRESS_MS = 350L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private TextView button;
    private WindowManager.LayoutParams lp;
    private String macro = "";
    private GradientDrawable bgNormal, bgPressed;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForegroundCompat();
        if (intent != null) {
            String m = intent.getStringExtra("macro");
            if (m != null) macro = m;
            String label = intent.getStringExtra("label");
            showButton(label == null ? "" : label);
        }
        return START_NOT_STICKY;
    }

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent stop = new Intent(this, FloatLauncherActivity.class);
        stop.putExtra("action", "stop");
        stop.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "悬浮按钮",
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle("映射悬浮按钮运行中")
                .setContentText("点此通知可关闭悬浮按钮")
                .setContentIntent(pi);
        startForeground(1, b.build());
    }

    private GradientDrawable circle(int fill, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(fill);
        d.setStroke(dp(2), stroke);
        return d;
    }

    private void showButton(String label) {
        removeButton();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int size = dp(64);

        button = new TextView(this);
        button.setText(label.length() > 4 ? label.substring(0, 4) : label);
        button.setTextSize(18);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(Color.rgb(28, 28, 30));
        bgNormal = circle(Color.argb(130, 255, 255, 255), Color.argb(210, 255, 255, 255));
        bgPressed = circle(Color.argb(190, 120, 180, 255), Color.argb(230, 0, 122, 255));
        button.setBackground(bgNormal);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        lp.x = dm.widthPixels - size - dp(16);
        lp.y = dm.heightPixels / 2;

        button.setOnTouchListener(new TouchHandler());
        wm.addView(button, lp);
    }

    private void removeButton() {
        if (button != null && wm != null) {
            try {
                wm.removeView(button);
            } catch (Exception ignored) { }
        }
        button = null;
    }

    private void warnNoIme() {
        Toast.makeText(getApplicationContext(),
                "请先切换到「映射」输入法，并点开一个输入框", Toast.LENGTH_SHORT).show();
    }

    private class TouchHandler implements View.OnTouchListener, Runnable {
        private float downX, downY;
        private int startX, startY;
        private boolean moved, holding;
        private final int slop = ViewConfiguration.get(FloatService.this).getScaledTouchSlop();

        /** 长按触发：开始循环输入 */
        @Override
        public void run() {
            holding = true;
            if (button != null) button.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            MapInputMethodService s = MapInputMethodService.instance;
            if (s == null) warnNoIme(); else s.startHold(macro);
        }

        @Override
        public boolean onTouch(View v, MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = ev.getRawX();
                    downY = ev.getRawY();
                    startX = lp.x;
                    startY = lp.y;
                    moved = false;
                    holding = false;
                    button.setBackground(bgPressed);
                    handler.postDelayed(this, LONG_PRESS_MS);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!holding) {
                        float dx = ev.getRawX() - downX;
                        float dy = ev.getRawY() - downY;
                        if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                            moved = true;
                            handler.removeCallbacks(this);
                        }
                        if (moved) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            try {
                                wm.updateViewLayout(button, lp);
                            } catch (Exception ignored) { }
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(this);
                    button.setBackground(bgNormal);
                    MapInputMethodService s = MapInputMethodService.instance;
                    if (holding) {
                        if (s != null) s.stopHold();
                    } else if (!moved && ev.getActionMasked() == MotionEvent.ACTION_UP) {
                        if (s == null) warnNoIme(); else s.tapOnce(macro);
                    }
                    holding = false;
                    return true;
                default:
                    return true;
            }
        }
    }

    @Override
    public void onDestroy() {
        removeButton();
        MapInputMethodService s = MapInputMethodService.instance;
        if (s != null) s.stopHold();
        super.onDestroy();
    }
}
