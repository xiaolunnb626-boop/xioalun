package com.DL.mapime;

import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 悬浮按钮服务，可同时显示多个按钮，每个按钮对应一个宏（多个步骤）。
 *
 * 每个按钮由两个悬浮窗组成：
 *   1) 外观窗：显示形状/填充/边框/文字，完全不接收触摸（NOT_TOUCHABLE），
 *      需要「内部模糊」时用 Dialog 窗口的 backgroundBlur，只模糊按钮范围内的背景；
 *   2) 触发窗：透明，位于按钮中心，大小为「触发区」百分比，只有手指落在这里才会触发/拖动；
 *      落在外观窗其余部分的手指会直接穿透到下面的应用，可以在按钮范围内滑动屏幕。
 *
 * 触发窗上：长按 = 持续输入，松手停止；轻点 = 输入一遍；拖动 = 移动（未固定时）。
 */
public class FloatService extends Service {
    static volatile FloatService instance;

    private static final String CHANNEL = "float_btn";
    private static final long LONG_PRESS_MS = 350L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private SharedPreferences posPrefs;

    private static class FloatBtn {
        String id, macro;
        TextView view;                 // 外观
        View touch;                    // 触发区
        WindowManager.LayoutParams lp; // 外观窗参数（普通窗口时使用）
        WindowManager.LayoutParams tlp;
        Dialog dlg;                    // 使用模糊时，外观窗是 Dialog 窗口
        Drawable bgNormal, bgPressed;
        boolean locked;
        int x, y, wpx, hpx, tw, th;
    }

    /**
     * cfg："高度dp,边框dp,填充(0-255),模糊(0-100),固定(0/1),形状(0-6),圆角%,宽高比%,触发区%"
     */
    private static int[] parseCfg(String cfg) {
        int[] v = {64, 2, 130, 0, 0, 0, 50, 100, 100};
        if (cfg != null) {
            String[] parts = cfg.split(",");
            for (int i = 0; i < parts.length && i < v.length; i++) {
                try {
                    v[i] = Integer.parseInt(parts[i].trim());
                } catch (Exception ignored) { }
            }
        }
        v[0] = Math.max(32, Math.min(160, v[0]));
        v[1] = Math.max(0, Math.min(12, v[1]));
        v[2] = Math.max(0, Math.min(255, v[2]));
        v[3] = Math.max(0, Math.min(100, v[3]));
        if (v[5] < 0 || v[5] > 6) v[5] = 0;
        v[6] = Math.max(0, Math.min(50, v[6]));
        v[7] = Math.max(50, Math.min(200, v[7]));
        v[8] = Math.max(20, Math.min(100, v[8]));
        return v;
    }

    private final LinkedHashMap<String, FloatBtn> buttons = new LinkedHashMap<String, FloatBtn>();
    /** 当前被按住（长按中）的按钮：id -> 宏名 */
    private final LinkedHashMap<String, String> held = new LinkedHashMap<String, String>();

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        posPrefs = getSharedPreferences("float_pos", MODE_PRIVATE);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String id = intent.getStringExtra("id");
            String macro = intent.getStringExtra("macro");
            String label = intent.getStringExtra("label");
            String cfg = intent.getStringExtra("cfg");
            if (macro != null && macro.length() > 0) {
                if (id == null || id.length() == 0) id = macro;
                addButton(id, macro, label == null ? "" : label, cfg);
            }
        }
        startForegroundCompat();
        if (buttons.isEmpty()) stopSelf();
        return START_NOT_STICKY;
    }

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent stop = new Intent(this, FloatLauncherActivity.class);
        stop.putExtra("action", "stop");
        stop.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "悬浮按钮",
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle("映射悬浮按钮运行中（" + buttons.size() + " 个）")
                .setContentText("点此通知可关闭全部悬浮按钮")
                .setContentIntent(pi);
        startForeground(1, b.build());
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    /** 模糊区域的圆角：跟随按钮形状（圆形/胶囊/圆角矩形有圆角，其余按矩形） */
    private float blurCorner(int[] c, int wpx, int hpx) {
        float m = Math.min(wpx, hpx);
        switch (c[5]) {
            case 0:
            case 2:
                return m / 2f;
            case 1:
                return m * c[6] / 100f;
            default:
                return 0f;
        }
    }

    /** 带「只模糊按钮范围」的外观窗：Dialog 窗口 + 窗口背景模糊（Android 12+） */
    private boolean showBlurWindow(FloatBtn b, int[] c) {
        if (Build.VERSION.SDK_INT < 31) return false;
        try {
            Context themed = new ContextThemeWrapper(this,
                    android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
            Dialog d = new Dialog(themed);
            d.setContentView(b.view, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            Window w = d.getWindow();
            w.setType(overlayType());
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
            w.setFormat(PixelFormat.TRANSLUCENT);
            // 透明但带圆角轮廓的背景：系统按它的圆角裁剪模糊区域
            GradientDrawable clip = new GradientDrawable();
            clip.setColor(Color.TRANSPARENT);
            clip.setCornerRadius(blurCorner(c, b.wpx, b.hpx));
            w.setBackgroundDrawable(clip);
            w.setBackgroundBlurRadius(c[3]);
            w.setLayout(b.wpx, b.hpx);
            w.setGravity(Gravity.TOP | Gravity.START);
            WindowManager.LayoutParams a = w.getAttributes();
            a.x = b.x;
            a.y = b.y;
            a.windowAnimations = 0;
            w.setAttributes(a);
            d.show();
            b.dlg = d;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void addButton(String id, String macro, String label, String cfg) {
        removeViewOnly(id);   // 同 id 重复添加：刷新
        int[] c = parseCfg(cfg);
        int hpx = dp(c[0]);
        int wpx = Math.max(dp(32), hpx * c[7] / 100);
        int size = Math.min(wpx, hpx);
        int borderPx = c[1] == 0 ? 0 : Math.max(1, dp(c[1]));
        int fill = c[2];

        FloatBtn b = new FloatBtn();
        b.id = id;
        b.macro = macro;
        b.locked = c[4] == 1;
        b.wpx = wpx;
        b.hpx = hpx;
        b.tw = Math.min(wpx, Math.max(dp(24), wpx * c[8] / 100));
        b.th = Math.min(hpx, Math.max(dp(24), hpx * c[8] / 100));

        b.view = new TextView(this);
        b.view.setText(label.length() > 4 ? label.substring(0, 4) : label);
        b.view.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.28f);
        b.view.setTypeface(Typeface.DEFAULT_BOLD);
        b.view.setGravity(Gravity.CENTER);
        b.view.setTextColor(Color.rgb(28, 28, 30));
        b.bgNormal = new ShapeBg(c[5], c[6], Color.argb(fill, 255, 255, 255),
                Color.argb(210, 255, 255, 255), borderPx);
        b.bgPressed = new ShapeBg(c[5], c[6], Color.argb(Math.min(255, fill + 60), 120, 180, 255),
                Color.argb(230, 0, 122, 255), borderPx);
        b.view.setBackground(b.bgNormal);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int defX = dm.widthPixels - wpx - dp(16);
        int defY = dm.heightPixels / 2 + buttons.size() * dp(76);
        if (defY > dm.heightPixels - hpx - dp(40)) defY = dp(120) + buttons.size() * dp(8);
        b.x = posPrefs.getInt("x_" + id, defX);
        b.y = posPrefs.getInt("y_" + id, defY);

        int type = overlayType();
        boolean shown = false;
        if (c[3] > 0) shown = showBlurWindow(b, c);   // 内部模糊
        if (!shown) {
            b.lp = new WindowManager.LayoutParams(wpx, hpx, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            b.lp.gravity = Gravity.TOP | Gravity.START;
            b.lp.x = b.x;
            b.lp.y = b.y;
            try {
                wm.addView(b.view, b.lp);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "悬浮窗创建失败：请确认已允许显示在其他应用上层",
                        Toast.LENGTH_LONG).show();
                return;
            }
        }

        // 触发窗（在外观窗之上）：只有这一块会接收触摸
        b.touch = new View(this);
        b.tlp = new WindowManager.LayoutParams(b.tw, b.th, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        b.tlp.gravity = Gravity.TOP | Gravity.START;
        b.tlp.x = b.x + (wpx - b.tw) / 2;
        b.tlp.y = b.y + (hpx - b.th) / 2;
        b.touch.setOnTouchListener(new TouchHandler(b));
        try {
            wm.addView(b.touch, b.tlp);
            buttons.put(id, b);
        } catch (Exception e) {
            removeWindows(b);
            Toast.makeText(getApplicationContext(), "悬浮窗创建失败：请确认已允许显示在其他应用上层",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void removeWindows(FloatBtn b) {
        try {
            if (b.dlg != null) b.dlg.dismiss();
            else if (b.view != null) wm.removeView(b.view);
        } catch (Exception ignored) { }
        try {
            if (b.touch != null) wm.removeView(b.touch);
        } catch (Exception ignored) { }
    }

    private void removeViewOnly(String id) {
        FloatBtn old = buttons.remove(id);
        if (old != null) removeWindows(old);
        held.remove(id);
    }

    /** 拖动时同步移动外观窗和触发窗 */
    private void place(FloatBtn b) {
        try {
            if (b.dlg != null) {
                Window w = b.dlg.getWindow();
                WindowManager.LayoutParams a = w.getAttributes();
                a.x = b.x;
                a.y = b.y;
                w.setAttributes(a);
            } else {
                b.lp.x = b.x;
                b.lp.y = b.y;
                wm.updateViewLayout(b.view, b.lp);
            }
            b.tlp.x = b.x + (b.wpx - b.tw) / 2;
            b.tlp.y = b.y + (b.hpx - b.th) / 2;
            wm.updateViewLayout(b.touch, b.tlp);
        } catch (Exception ignored) { }
    }

    /** 修改已显示按钮的外观/固定状态；没有显示的按钮不会被创建 */
    public void updateButton(String id, String macro, String label, String cfg) {
        FloatBtn old = buttons.get(id);
        if (old == null) return;
        posPrefs.edit().putInt("x_" + id, old.x).putInt("y_" + id, old.y).apply();
        addButton(id, macro, label == null ? "" : label, cfg);
    }

    /** 关闭单个悬浮按钮（由 FloatLauncherActivity 调用） */
    public void removeButtonById(String id) {
        removeViewOnly(id);
        refreshHold();
        if (buttons.isEmpty()) {
            stopSelf();
        } else {
            startForegroundCompat();
        }
    }

    private void warnNoIme() {
        Toast.makeText(getApplicationContext(),
                "请先切换到「映射」输入法，并点开一个输入框", Toast.LENGTH_SHORT).show();
    }

    /** 按住状态变化后：没人按住就停止；还有别的按钮按着就改为循环它 */
    private void refreshHold() {
        MapInputMethodService s = MapInputMethodService.instance;
        if (s == null) return;
        if (held.isEmpty()) {
            s.stopHold();
        } else {
            String last = null;
            for (String m : held.values()) last = m;
            s.startHold(last);
        }
    }

    private class TouchHandler implements View.OnTouchListener, Runnable {
        private final FloatBtn b;
        private float downX, downY;
        private int startX, startY;
        private boolean moved, holding;
        private final int slop = ViewConfiguration.get(FloatService.this).getScaledTouchSlop();

        TouchHandler(FloatBtn b) {
            this.b = b;
        }

        /** 长按触发：开始循环输入 */
        @Override
        public void run() {
            holding = true;
            b.touch.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            MapInputMethodService s = MapInputMethodService.instance;
            if (s == null) {
                warnNoIme();
            } else {
                held.put(b.id, b.macro);
                s.startHold(b.macro);
            }
        }

        @Override
        public boolean onTouch(View v, MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = ev.getRawX();
                    downY = ev.getRawY();
                    startX = b.x;
                    startY = b.y;
                    moved = false;
                    holding = false;
                    b.view.setBackground(b.bgPressed);
                    handler.postDelayed(this, LONG_PRESS_MS);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!holding && !b.locked) {
                        float dx = ev.getRawX() - downX;
                        float dy = ev.getRawY() - downY;
                        if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                            moved = true;
                            handler.removeCallbacks(this);
                        }
                        if (moved) {
                            b.x = startX + (int) dx;
                            b.y = startY + (int) dy;
                            place(b);
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(this);
                    b.view.setBackground(b.bgNormal);
                    MapInputMethodService s = MapInputMethodService.instance;
                    if (holding) {
                        held.remove(b.id);
                        refreshHold();
                    } else if (moved) {
                        posPrefs.edit().putInt("x_" + b.id, b.x).putInt("y_" + b.id, b.y).apply();
                    } else if (ev.getActionMasked() == MotionEvent.ACTION_UP) {
                        if (s == null) warnNoIme(); else s.tapOnce(b.macro);
                    }
                    holding = false;
                    return true;
                default:
                    return true;
            }
        }
    }

    @Override
    public void onDestroy() {
        for (Map.Entry<String, FloatBtn> e : buttons.entrySet()) {
            removeWindows(e.getValue());
        }
        buttons.clear();
        held.clear();
        MapInputMethodService s = MapInputMethodService.instance;
        if (s != null) s.stopHold();
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
