package com.DL.mapime;

import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 悬浮按钮服务，可同时显示多个按钮，每个按钮对应一个宏（多个步骤）。
 *
 * 每个按钮由两个悬浮窗组成：
 *   1) 外观窗：显示形状/填充/边框/文字，完全不接收触摸（NOT_TOUCHABLE），
 *      需要「内部模糊」时用 Dialog 窗口的 backgroundBlur，只模糊按钮范围内的背景；
 *   2) 触发窗：透明，位于按钮中心，大小为「触发区」百分比，只有手指落在这里才会触发/拖动；
 *      落在外观窗其余部分的手指会直接穿透到下面的应用，可以在按钮范围内滑动屏幕。
 *
 * 触发窗上：长按 = 持续输入，松手停止；轻点 = 输入一遍；拖动 = 移动（未固定时）；
 *   长按后滑动 = 让按钮下方可滚动的控件按页滚动（需开启「滚动辅助」无障碍服务）。
 * 触发窗带 FLAG_SPLIT_TOUCH：一根手指按住按钮时，另一根手指落在按钮以外的位置，
 * 会直接交给下方应用，可以边按住边自由滑动。
 */
public class FloatService extends Service {
    static volatile FloatService instance;

    private static final String CHANNEL = "float_btn";
    private static final long LONG_PRESS_MS = 350L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private SharedPreferences posPrefs;

    private static class FloatBtn {
        String id, macro;
        TextView view;                 // 外观
        View touch;                    // 触发区
        WindowManager.LayoutParams lp; // 外观窗参数（普通窗口时使用）
        WindowManager.LayoutParams tlp;
        Dialog dlg;                    // 使用模糊时，外观窗是 Dialog 窗口
        Drawable bgNormal, bgPressed;
        boolean locked;
        boolean through;               // 穿透监听：触发窗不拦截触摸，由 Shizuku 读取触摸来判断长按
        boolean latch, latched;        // 长按触发后锁定：松手后继续持续输入，再点一下才停止
        long longPressMs = 350L;       // 长按多久后触发映射（可在悬浮窗设置里自定义）
        boolean passSwipe;             // 长按后滑动：把滑动转发给下方应用（需无障碍服务）
        int x, y, wpx, hpx, tw, th;
    }

    /**
     * cfg："高度dp,边框dp,填充(0-255),模糊(0-100),固定(0/1),形状(0-6),圆角%,宽高比%,触发区%,长按滑动穿透(0/1),长按触发时间ms,长按后锁定(0/1),穿透监听(0/1)"
     */
    private static int[] parseCfg(String cfg) {
        int[] v = {64, 2, 130, 0, 0, 0, 50, 100, 100, 1, 350, 0, 0};
        if (cfg != null) {
            String[] parts = cfg.split(",");
            for (int i = 0; i < parts.length && i < v.length; i++) {
                try {
                    v[i] = Integer.parseInt(parts[i].trim());
                } catch (Exception ignored) { }
            }
        }
        v[0] = Math.max(32, Math.min(160, v[0]));
        v[1] = Math.max(0, Math.min(12, v[1]));
        v[2] = Math.max(0, Math.min(255, v[2]));
        v[3] = Math.max(0, Math.min(100, v[3]));
        if (v[5] < 0 || v[5] > 6) v[5] = 0;
        v[6] = Math.max(0, Math.min(50, v[6]));
        v[7] = Math.max(50, Math.min(200, v[7]));
        v[8] = Math.max(20, Math.min(100, v[8]));
        v[9] = v[9] == 0 ? 0 : 1;
        v[11] = v[11] == 1 ? 1 : 0;
        v[12] = v[12] == 1 ? 1 : 0;
        v[10] = Math.max(100, Math.min(10000, v[10]));   // 长按多久后触发：0.1~10 秒
        return v;
    }

    private final LinkedHashMap<String, FloatBtn> buttons = new LinkedHashMap<String, FloatBtn>();
    /** 当前被按住（长按中）的按钮：id -> 宏名 */
    private final LinkedHashMap<String, String> held = new LinkedHashMap<String, String>();

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        posPrefs = getSharedPreferences("float_pos", MODE_PRIVATE);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String id = intent.getStringExtra("id");
            String macro = intent.getStringExtra("macro");
            String label = intent.getStringExtra("label");
            String cfg = intent.getStringExtra("cfg");
            if (macro != null && macro.length() > 0) {
                if (id == null || id.length() == 0) id = macro;
                addButton(id, macro, label == null ? "" : label, cfg);
            }
        }
        startForegroundCompat();
        if (buttons.isEmpty()) stopSelf();
        return START_NOT_STICKY;
    }

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent stop = new Intent(this, FloatLauncherActivity.class);
        stop.putExtra("action", "stop");
        stop.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "悬浮按钮",
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle("映射悬浮按钮运行中（" + buttons.size() + " 个）")
                .setContentText("点此通知可关闭全部悬浮按钮")
                .setContentIntent(pi);
        startForeground(1, b.build());
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    /** 模糊区域的圆角：跟随按钮形状（圆形/胶囊/圆角矩形有圆角，其余按矩形） */
    private float blurCorner(int[] c, int wpx, int hpx) {
        float m = Math.min(wpx, hpx);
        switch (c[5]) {
            case 0:
            case 2:
                return m / 2f;
            case 1:
                return m * c[6] / 100f;
            default:
                return 0f;
        }
    }

    /** 带「只模糊按钮范围」的外观窗：Dialog 窗口 + 窗口背景模糊（Android 12+） */
    private boolean showBlurWindow(FloatBtn b, int[] c) {
        if (Build.VERSION.SDK_INT < 31) return false;
        try {
            if (!wm.isCrossWindowBlurEnabled()) {
                Toast.makeText(getApplicationContext(),
                        "系统关闭了窗口模糊（省电模式或开发者选项里的“停用窗口模糊”），内部模糊无效",
                        Toast.LENGTH_LONG).show();
            }
            Context themed = new ContextThemeWrapper(this,
                    android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
            Dialog d = new Dialog(themed);
            d.setContentView(b.view, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            Window w = d.getWindow();
            w.setType(overlayType());
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED   // 背景模糊依赖硬件加速
                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
            w.setFormat(PixelFormat.TRANSLUCENT);
            // 透明但带圆角轮廓的背景：系统按它的圆角裁剪模糊区域
            GradientDrawable clip = new GradientDrawable();
            clip.setColor(Color.TRANSPARENT);
            clip.setCornerRadius(blurCorner(c, b.wpx, b.hpx));
            w.setBackgroundDrawable(clip);
            w.setBackgroundBlurRadius(c[3]);
            w.setLayout(b.wpx, b.hpx);
            w.setGravity(Gravity.TOP | Gravity.START);
            WindowManager.LayoutParams a = w.getAttributes();
            a.x = b.x;
            a.y = b.y;
            a.windowAnimations = 0;
            w.setAttributes(a);
            d.show();
            b.dlg = d;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void addButton(String id, String macro, String label, String cfg) {
        removeViewOnly(id);   // 同 id 重复添加：刷新
        int[] c = parseCfg(cfg);
        int hpx = dp(c[0]);
        int wpx = Math.max(dp(32), hpx * c[7] / 100);
        int size = Math.min(wpx, hpx);
        int borderPx = c[1] == 0 ? 0 : Math.max(1, dp(c[1]));
        int fill = c[2];

        FloatBtn b = new FloatBtn();
        b.id = id;
        b.macro = macro;
        b.locked = c[4] == 1;
        b.passSwipe = c[9] == 1;
        b.longPressMs = c[10];
        b.latch = c[11] == 1;
        if (c[12] == 1) {
            if (ShizukuInjector.isRunning() && ShizukuInjector.hasPermission()) {
                b.through = true;
            } else {
                toast("穿透监听需要先启动并授权 Shizuku，已按普通触摸模式显示");
            }
        }
        b.wpx = wpx;
        b.hpx = hpx;
        b.tw = Math.min(wpx, Math.max(dp(24), wpx * c[8] / 100));
        b.th = Math.min(hpx, Math.max(dp(24), hpx * c[8] / 100));

        b.view = new TextView(this);
        b.view.setText(label.length() > 4 ? label.substring(0, 4) : label);
        b.view.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.28f);
        b.view.setTypeface(Typeface.DEFAULT_BOLD);
        b.view.setGravity(Gravity.CENTER);
        b.view.setTextColor(Color.rgb(28, 28, 30));
        b.bgNormal = new ShapeBg(c[5], c[6], Color.argb(fill, 255, 255, 255),
                Color.argb(210, 255, 255, 255), borderPx);
        b.bgPressed = new ShapeBg(c[5], c[6], Color.argb(Math.min(255, fill + 60), 120, 180, 255),
                Color.argb(230, 0, 122, 255), borderPx);
        b.view.setBackground(b.bgNormal);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int defX = dm.widthPixels - wpx - dp(16);
        int defY = dm.heightPixels / 2 + buttons.size() * dp(76);
        if (defY > dm.heightPixels - hpx - dp(40)) defY = dp(120) + buttons.size() * dp(8);
        b.x = posPrefs.getInt("x_" + id, defX);
        b.y = posPrefs.getInt("y_" + id, defY);

        int type = overlayType();
        boolean shown = false;
        if (c[3] > 0) shown = showBlurWindow(b, c);   // 内部模糊
        if (!shown) {
            b.lp = new WindowManager.LayoutParams(wpx, hpx, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            b.lp.gravity = Gravity.TOP | Gravity.START;
            b.lp.x = b.x;
            b.lp.y = b.y;
            try {
                wm.addView(b.view, b.lp);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "悬浮窗创建失败：请确认已允许显示在其他应用上层",
                        Toast.LENGTH_LONG).show();
                return;
            }
        }

        // 触发窗（在外观窗之上）：只有这一块会接收触摸
        b.touch = new View(this);
        b.tlp = new WindowManager.LayoutParams(b.tw, b.th, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_SPLIT_TOUCH     // 按住按钮时，另一根手指可以操作下方应用
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | (b.through ? WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE : 0),
                PixelFormat.TRANSLUCENT);
        b.tlp.gravity = Gravity.TOP | Gravity.START;
        b.tlp.x = b.x + (wpx - b.tw) / 2;
        b.tlp.y = b.y + (hpx - b.th) / 2;
        b.touch.setOnTouchListener(new TouchHandler(b));
        try {
            wm.addView(b.touch, b.tlp);
            buttons.put(id, b);
            startWatcherIfNeeded();
        } catch (Exception e) {
            removeWindows(b);
            Toast.makeText(getApplicationContext(), "悬浮窗创建失败：请确认已允许显示在其他应用上层",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void removeWindows(FloatBtn b) {
        try {
            if (b.dlg != null) b.dlg.dismiss();
            else if (b.view != null) wm.removeView(b.view);
        } catch (Exception ignored) { }
        try {
            if (b.touch != null) wm.removeView(b.touch);
        } catch (Exception ignored) { }
    }

    private void removeViewOnly(String id) {
        FloatBtn old = buttons.remove(id);
        if (old != null) removeWindows(old);
        held.remove(id);
        refreshHold();       // 删除/更新按钮时，如果它处于锁定持续输入中，一并停止
        handler.post(watcherCheckRunnable);
    }

    /** 拖动时同步移动外观窗和触发窗 */
    private void place(FloatBtn b) {
        try {
            if (b.dlg != null) {
                Window w = b.dlg.getWindow();
                WindowManager.LayoutParams a = w.getAttributes();
                a.x = b.x;
                a.y = b.y;
                w.setAttributes(a);
            } else {
                b.lp.x = b.x;
                b.lp.y = b.y;
                wm.updateViewLayout(b.view, b.lp);
            }
            b.tlp.x = b.x + (b.wpx - b.tw) / 2;
            b.tlp.y = b.y + (b.hpx - b.th) / 2;
            wm.updateViewLayout(b.touch, b.tlp);
        } catch (Exception ignored) { }
    }

    /** 修改已显示按钮的外观/固定状态；没有显示的按钮不会被创建 */
    public void updateButton(String id, String macro, String label, String cfg) {
        FloatBtn old = buttons.get(id);
        if (old == null) return;
        posPrefs.edit().putInt("x_" + id, old.x).putInt("y_" + id, old.y).apply();
        addButton(id, macro, label == null ? "" : label, cfg);
    }

    /** 关闭单个悬浮按钮（由 FloatLauncherActivity 调用） */
    public void removeButtonById(String id) {
        removeViewOnly(id);
        refreshHold();
        if (buttons.isEmpty()) {
            stopSelf();
        } else {
            startForegroundCompat();
        }
    }

    private boolean warnedA11y = false;

    private void toast(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }

    /** 重放手势期间，让所有触发窗不接收触摸，否则重放的手势会落到悬浮按钮自己身上 */
    private void setTriggersTouchable(boolean touchable) {
        for (FloatBtn fb : buttons.values()) {
            if (fb.touch == null || fb.tlp == null) continue;
            if (touchable) {
                fb.tlp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            } else {
                fb.tlp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            }
            try {
                wm.updateViewLayout(fb.touch, fb.tlp);
            } catch (Exception ignored) { }
        }
    }

    /**
     * 注入触摸前把触发窗缩成屏幕角落的 1x1：这样注入的触摸不会落在悬浮按钮上，
     * 而真实手指的触摸仍然继续送给触发窗（改窗口大小/位置不会中断正在进行的触摸，和拖动悬浮窗一样）。
     */
    private void shrinkTriggers(boolean shrink) {
        for (FloatBtn fb : buttons.values()) {
            if (fb.touch == null || fb.tlp == null) continue;
            if (shrink) {
                fb.tlp.width = 1;
                fb.tlp.height = 1;
                fb.tlp.x = 0;
                fb.tlp.y = 0;
            } else {
                fb.tlp.width = fb.tw;
                fb.tlp.height = fb.th;
                fb.tlp.x = fb.x + (fb.wpx - fb.tw) / 2;
                fb.tlp.y = fb.y + (fb.hpx - fb.th) / 2;
            }
            try {
                wm.updateViewLayout(fb.touch, fb.tlp);
            } catch (Exception ignored) { }
        }
    }

    private final Runnable restoreTouchRunnable = new Runnable() {
        @Override public void run() {
            handler.removeCallbacks(this);
            setTriggersTouchable(true);
            shrinkTriggers(false);
        }
    };

    /** 手指抬起后重放滑动轨迹到下方应用 */
    private void replayTrail(final float[] pts, final long durMs) {
        final SwipeAccessibilityService a = SwipeAccessibilityService.instance;
        if (a == null) {
            warnNoA11y();
            return;
        }
        setTriggersTouchable(false);
        // 等窗口标志生效后再注入（updateViewLayout 是异步的）
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                boolean ok = a.replay(pts, durMs, restoreTouchRunnable);
                if (!ok) {
                    toast("无障碍手势发送失败：请在系统设置里关掉再重新开启「映射输入法·滚动辅助」");
                    restoreTouchRunnable.run();
                }
            }
        }, 90L);
        // 兜底：万一回调没来，也要把触发窗恢复
        handler.postDelayed(restoreTouchRunnable, durMs + 1500L);
    }

    // ======================= 穿透监听模式（Shizuku 读取触摸）=======================
    private TouchWatcher watcher;
    private final java.util.HashMap<Integer, PassTouch> passTouches = new java.util.HashMap<Integer, PassTouch>();

    private static class PassTouch {
        FloatBtn b;
        float downX, downY;
        boolean triggered, dead;
        Runnable timer;
    }

    private final Runnable watcherCheckRunnable = new Runnable() {
        @Override public void run() {
            startWatcherIfNeeded();
        }
    };

    private void startWatcherIfNeeded() {
        boolean any = false;
        for (FloatBtn fb : buttons.values()) {
            if (fb.through) any = true;
        }
        if (!any) {
            stopWatcher();
            return;
        }
        if (watcher != null) return;
        watcher = new TouchWatcher(new TouchWatcher.Listener() {
            @Override public void onDown(int id, int rx, int ry) { passDown(id, rx, ry); }
            @Override public void onMove(int id, int rx, int ry) { passMove(id, rx, ry); }
            @Override public void onUp(int id) { passUp(id); }
            @Override public void onError(String msg) {
                toast("穿透监听失败：" + msg + "；已恢复为普通触摸模式");
                fallbackThrough();
            }
        });
        watcher.start();
    }

    private void stopWatcher() {
        if (watcher != null) {
            watcher.stop();
            watcher = null;
        }
        passTouches.clear();
    }

    /** 监听不可用时，把所有穿透按钮恢复成普通可触摸 */
    private void fallbackThrough() {
        stopWatcher();
        for (FloatBtn fb : buttons.values()) {
            if (!fb.through) continue;
            fb.through = false;
            if (fb.tlp != null && fb.touch != null) {
                fb.tlp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                try {
                    wm.updateViewLayout(fb.touch, fb.tlp);
                } catch (Exception ignored) { }
            }
        }
    }

    /** 触摸屏原始坐标 → 屏幕坐标（考虑屏幕旋转） */
    private float[] rawToScreen(int rx, int ry) {
        android.view.Display d = wm.getDefaultDisplay();
        android.graphics.Point real = new android.graphics.Point();
        d.getRealSize(real);
        int rot = d.getRotation();
        boolean land = rot == android.view.Surface.ROTATION_90 || rot == android.view.Surface.ROTATION_270;
        float pw = land ? real.y : real.x;     // 自然（竖屏）方向下的宽、高
        float ph = land ? real.x : real.y;
        float px = rx * pw / (TouchWatcher.rawMaxX + 1f);
        float py = ry * ph / (TouchWatcher.rawMaxY + 1f);
        float sx, sy;
        if (rot == android.view.Surface.ROTATION_90) {
            sx = py;
            sy = pw - px;
        } else if (rot == android.view.Surface.ROTATION_180) {
            sx = pw - px;
            sy = ph - py;
        } else if (rot == android.view.Surface.ROTATION_270) {
            sx = ph - py;
            sy = px;
        } else {
            sx = px;
            sy = py;
        }
        return new float[]{sx, sy};
    }

    private boolean inButton(FloatBtn fb, float x, float y) {
        if (fb.touch == null) return false;
        int[] loc = new int[2];
        fb.touch.getLocationOnScreen(loc);
        int w = fb.touch.getWidth() > 0 ? fb.touch.getWidth() : fb.tw;
        int h = fb.touch.getHeight() > 0 ? fb.touch.getHeight() : fb.th;
        return x >= loc[0] && x <= loc[0] + w && y >= loc[1] && y <= loc[1] + h;
    }

    private void passDown(int id, int rx, int ry) {
        float[] p = rawToScreen(rx, ry);
        for (final FloatBtn fb : buttons.values()) {
            if (!fb.through || !inButton(fb, p[0], p[1])) continue;
            final PassTouch pt = new PassTouch();
            pt.b = fb;
            pt.downX = p[0];
            pt.downY = p[1];
            final int fid = id;
            pt.timer = new Runnable() {
                @Override public void run() {
                    if (pt.dead || passTouches.get(fid) != pt) return;
                    pt.triggered = true;
                    try {
                        fb.touch.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    } catch (Exception ignored) { }
                    MapInputMethodService s = MapInputMethodService.instance;
                    if (s == null) {
                        warnNoIme();
                    } else {
                        held.put(fb.id, fb.macro);
                        s.startHold(fb.macro);
                    }
                }
            };
            passTouches.put(id, pt);
            fb.view.setBackground(fb.bgPressed);
            handler.postDelayed(pt.timer, fb.longPressMs);
            return;
        }
    }

    private void passMove(int id, int rx, int ry) {
        PassTouch pt = passTouches.get(id);
        if (pt == null || pt.triggered || pt.dead) return;
        float[] p = rawToScreen(rx, ry);
        float dx = p[0] - pt.downX, dy = p[1] - pt.downY;
        float limit = ViewConfiguration.get(this).getScaledTouchSlop() * 3f;
        if (dx * dx + dy * dy > limit * limit) {
            // 长按还没触发就滑远了：说明只是在操作游戏，不触发映射
            pt.dead = true;
            handler.removeCallbacks(pt.timer);
            pt.b.view.setBackground(pt.b.bgNormal);
        }
    }

    private void passUp(int id) {
        PassTouch pt = passTouches.remove(id);
        if (pt == null) return;
        handler.removeCallbacks(pt.timer);
        pt.b.view.setBackground(pt.b.bgNormal);
        if (pt.triggered) {
            held.remove(pt.b.id);
            refreshHold();
        } else if (!pt.dead) {
            MapInputMethodService s = MapInputMethodService.instance;
            if (s == null) warnNoIme(); else s.tapOnce(pt.b.macro);
        }
    }

    private void warnNoA11y() {
        if (warnedA11y) return;
        warnedA11y = true;
        Toast.makeText(getApplicationContext(),
                "长按后滑动要带动下方应用滚动，需要先开启「映射输入法·滚动辅助」无障碍服务（打开映射输入法 App 里的第③项）",
                Toast.LENGTH_LONG).show();
    }

    private void warnNoIme() {
        Toast.makeText(getApplicationContext(),
                "请先切换到「映射」输入法，并点开一个输入框", Toast.LENGTH_SHORT).show();
    }

    /** 按住状态变化后：没人按住就停止；还有别的按钮按着就改为循环它 */
    private void refreshHold() {
        MapInputMethodService s = MapInputMethodService.instance;
        if (s == null) return;
        if (held.isEmpty()) {
            s.stopHold();
        } else {
            String last = null;
            for (String m : held.values()) last = m;
            s.startHold(last);
        }
    }

    private class TouchHandler implements View.OnTouchListener, Runnable {
        private final FloatBtn b;
        private float downX, downY;
        private int startX, startY;
        private boolean moved, holding, wasLatched;
        private float anchorX, anchorY;      // 上一次触发滚动时的手指位置
        private long lastScrollAt;
        private final java.util.ArrayList<float[]> trail = new java.util.ArrayList<float[]>();
        private boolean scrolledLive;        // 滑动过程中已经用滚动动作带动过下方应用
        private boolean notedNoScroll;       // 本次触摸已提示过「没找到可滚动控件」
        // —— Shizuku 注入：在下方应用上「再按一根手指」实时跟手 ——
        private boolean injecting, injectPending, injectTried, injectFailed;
        private long injectDownTime, injectStartAt;
        private int injectScrollBase;
        private float lastRawX, lastRawY;
        private long trailT0;
        private final int slop = ViewConfiguration.get(FloatService.this).getScaledTouchSlop();

        TouchHandler(FloatBtn b) {
            this.b = b;
        }

        /** 长按触发：开始循环输入 */
        @Override
        public void run() {
            if (b.latched) return;     // 已经锁定：这次触摸只是用来解除锁定
            holding = true;
            b.touch.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            MapInputMethodService s = MapInputMethodService.instance;
            if (s == null) {
                warnNoIme();
            } else {
                held.put(b.id, b.macro);
                s.startHold(b.macro);
            }
        }

        /**
         * 长按期间滑动：每滑过一定距离，就让按钮位置下方的可滚动控件滚动一页
         * （无障碍滚动动作；不能用手势注入，系统会在手指按着时取消注入）。
         */
        private void recordTrail(float x, float y, boolean force) {
            if (trail.isEmpty()) {
                trail.add(new float[]{downX, downY});
                trailT0 = SystemClock.uptimeMillis();
            }
            float[] last = trail.get(trail.size() - 1);
            float ddx = x - last[0], ddy = y - last[1];
            if (!force && ddx * ddx + ddy * ddy < dp(6) * dp(6)) return;
            if (trail.size() >= 300) trail.remove(trail.size() - 1);   // 点太多时只保留最新终点
            trail.add(new float[]{x, y});
        }

        /** 尝试用 Shizuku 注入触摸；不可用时返回 false，由调用方退回无障碍方式 */
        private boolean tryStartInject() {
            if (!ShizukuInjector.isRunning()) {
                toast("Shizuku 没有运行，已改用无障碍滚动（启动 Shizuku 后可实时跟手）");
                return false;
            }
            if (!ShizukuInjector.hasPermission()) {
                ShizukuInjector.requestPermission();
                toast("请在 Shizuku 弹窗里允许「映射输入法」，然后重新长按滑动");
                return false;
            }
            if (!ShizukuInjector.prepare()) {
                toast("Shizuku 初始化失败：" + ShizukuInjector.lastError);
                return false;
            }
            injecting = true;
            injectPending = true;
            injectDownTime = SystemClock.uptimeMillis();
            injectStartAt = injectDownTime;
            injectScrollBase = SwipeAccessibilityService.scrollEvents;
            shrinkTriggers(true);              // 让注入的触摸不落在悬浮按钮上，而是落到下方应用
            final float sx = downX, sy = downY;
            final long dt = injectDownTime;
            handler.postDelayed(new Runnable() {
                @Override public void run() {
                    if (!injecting) return;
                    boolean ok = ShizukuInjector.inject(MotionEvent.ACTION_DOWN, sx, sy, dt, true);
                    if (!ok) {
                        String why = ShizukuInjector.lastError;
                        if (why == null || why.length() == 0) why = "可能是系统不允许两路触摸同时进行";
                        toast("Shizuku 注入被拒绝：" + why + "；已改用无障碍滚动");
                        injecting = false;
                        injectPending = false;
                        injectFailed = true;
                        handler.postDelayed(restoreTouchRunnable, 100L);
                        anchorX = lastRawX;
                        anchorY = lastRawY;
                        return;
                    }
                    injectPending = false;
                    toast("已通过 Shizuku 注入滑动");
                    ShizukuInjector.inject(MotionEvent.ACTION_MOVE, lastRawX, lastRawY, dt);
                }
            }, 80L);   // 等触发窗的「不接收触摸」标志生效
            return true;
        }

        private void injectMove() {
            if (injectPending) return;
            ShizukuInjector.inject(MotionEvent.ACTION_MOVE, lastRawX, lastRawY, injectDownTime);
            long now = SystemClock.uptimeMillis();
            // 注入了一阵子、手指也滑了不少，但下方应用没有任何滚动事件：说明系统没接收这路触摸
            if (now - injectStartAt > 700L
                    && SwipeAccessibilityService.instance != null
                    && SwipeAccessibilityService.scrollEvents == injectScrollBase
                    && (Math.abs(lastRawX - downX) > dp(80) || Math.abs(lastRawY - downY) > dp(80))) {
                ShizukuInjector.inject(MotionEvent.ACTION_UP, lastRawX, lastRawY, injectDownTime);
                injecting = false;
                injectFailed = true;
                handler.postDelayed(restoreTouchRunnable, 200L);
                toast("系统没有接收注入的触摸（可能不支持两路触摸同时进行），已改用无障碍滚动");
                anchorX = lastRawX;
                anchorY = lastRawY;
            }
        }

        private void handleSwipe(MotionEvent ev) {
            float tdx = ev.getRawX() - downX, tdy = ev.getRawY() - downY;
            lastRawX = ev.getRawX();
            lastRawY = ev.getRawY();
            if (!trail.isEmpty() || Math.abs(tdx) > slop || Math.abs(tdy) > slop) {
                recordTrail(ev.getRawX(), ev.getRawY(), false);
            }
            if (injecting) {
                injectMove();
                return;
            }
            if (!injectTried && !injectFailed && (Math.abs(tdx) > slop || Math.abs(tdy) > slop)) {
                injectTried = true;
                if (tryStartInject()) return;
            }
            if (injecting) return;
            float dx = ev.getRawX() - anchorX;
            float dy = ev.getRawY() - anchorY;
            int step = dp(70);
            if (Math.abs(dx) < step && Math.abs(dy) < step) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastScrollAt < 260L) return;     // 等上一次滚动动画走完
            SwipeAccessibilityService a = SwipeAccessibilityService.instance;
            if (a == null) {
                warnNoA11y();
                anchorX = ev.getRawX();
                anchorY = ev.getRawY();
                return;
            }
            if (a.scrollAt((int) downX, (int) downY, dx, dy)) {
                scrolledLive = true;
            } else if (!notedNoScroll) {
                notedNoScroll = true;
                toast("下方没有可滚动控件，松手后会重放滑动手势");
            }
            lastScrollAt = now;
            anchorX = ev.getRawX();
            anchorY = ev.getRawY();
        }

        @Override
        public boolean onTouch(View v, MotionEvent ev) {
            if (ev.getDeviceId() < 0) return true;   // Shizuku 注入的虚拟设备事件，不是真实手指
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = ev.getRawX();
                    downY = ev.getRawY();
                    startX = b.x;
                    startY = b.y;
                    moved = false;
                    holding = false;
                    anchorX = downX;
                    anchorY = downY;
                    lastScrollAt = 0L;
                    trail.clear();
                    scrolledLive = false;
                    notedNoScroll = false;
                    injecting = false;
                    injectPending = false;
                    injectTried = false;
                    injectFailed = false;
                    wasLatched = b.latched;
                    b.view.setBackground(b.bgPressed);
                    handler.postDelayed(this, b.longPressMs);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (holding && b.passSwipe) {
                        handleSwipe(ev);
                    }
                    if (!holding && !b.locked) {
                        float dx = ev.getRawX() - downX;
                        float dy = ev.getRawY() - downY;
                        if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                            moved = true;
                            handler.removeCallbacks(this);
                        }
                        if (moved) {
                            b.x = startX + (int) dx;
                            b.y = startY + (int) dy;
                            place(b);
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(this);
                    b.view.setBackground(b.bgNormal);
                    MapInputMethodService s = MapInputMethodService.instance;
                    if (wasLatched) {
                        // 锁定状态下再按一下：停止持续输入
                        b.latched = false;
                        wasLatched = false;
                        held.remove(b.id);
                        refreshHold();
                        holding = false;
                        return true;
                    }
                    boolean latchNow = holding && b.latch
                            && ev.getActionMasked() == MotionEvent.ACTION_UP;
                    if (holding) {
                        if (latchNow) {
                            b.latched = true;                    // 松手后继续持续输入
                            b.view.setBackground(b.bgPressed);
                        } else {
                            held.remove(b.id);
                            refreshHold();
                        }
                        if (injecting) {
                            if (!injectPending) {
                                ShizukuInjector.inject(MotionEvent.ACTION_UP, ev.getRawX(), ev.getRawY(), injectDownTime);
                            }
                            injecting = false;
                            injectPending = false;
                            handler.postDelayed(restoreTouchRunnable, 200L);
                            scrolledLive = true;          // 已经实时带动过下方应用，不再重放
                        }
                        // 松手：滑动过程中没能用滚动动作带动下方应用的话，把整段滑动重放一遍
                        if (ev.getActionMasked() == MotionEvent.ACTION_UP && b.passSwipe
                                && !scrolledLive && !trail.isEmpty()) {
                            recordTrail(ev.getRawX(), ev.getRawY(), true);
                            if (trail.size() >= 2) {
                                float[] pts = new float[trail.size() * 2];
                                for (int i = 0; i < trail.size(); i++) {
                                    pts[2 * i] = trail.get(i)[0];
                                    pts[2 * i + 1] = trail.get(i)[1];
                                }
                                replayTrail(pts, SystemClock.uptimeMillis() - trailT0);
                            }
                        }
                        trail.clear();
                    } else if (moved) {
                        posPrefs.edit().putInt("x_" + b.id, b.x).putInt("y_" + b.id, b.y).apply();
                    } else if (ev.getActionMasked() == MotionEvent.ACTION_UP) {
                        if (s == null) warnNoIme(); else s.tapOnce(b.macro);
                    }
                    holding = false;
                    return true;
                default:
                    return true;
            }
        }
    }

    @Override
    public void onDestroy() {
        for (Map.Entry<String, FloatBtn> e : buttons.entrySet()) {
            removeWindows(e.getValue());
        }
        buttons.clear();
        held.clear();
        handler.removeCallbacks(restoreTouchRunnable);
        stopWatcher();
        MapInputMethodService s = MapInputMethodService.instance;
        if (s != null) s.stopHold();
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
