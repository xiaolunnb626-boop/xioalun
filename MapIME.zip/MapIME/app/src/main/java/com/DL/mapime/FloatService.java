package com.DL.mapime;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 悬浮按钮服务，可同时显示多个按钮，每个按钮对应一个宏（多个步骤）：
 *   长按按钮 —— 通过「映射」输入法循环输入该宏的所有步骤，松手停止；
 *   点一下   —— 只输入一遍；
 *   拖动     —— 移动按钮位置（位置会记住）。
 */
public class FloatService extends Service {
    static volatile FloatService instance;

    private static final String CHANNEL = "float_btn";
    private static final long LONG_PRESS_MS = 350L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private SharedPreferences posPrefs;

    private static class FloatBtn {
        String id, macro;
        TextView view;
        WindowManager.LayoutParams lp;
        Drawable bgNormal, bgPressed;
        boolean locked;      // 固定：不能拖动
    }

    /** cfg 格式："高度dp,边框dp,填充(0-255),模糊(0-100),固定(0/1),形状(0-5),圆角%,宽高比%" */
    private static int[] parseCfg(String cfg) {
        int[] v = {64, 2, 130, 0, 0, 0, 50, 100};
        if (cfg == null) return v;
        String[] parts = cfg.split(",");
        for (int i = 0; i < parts.length && i < v.length; i++) {
            try {
                v[i] = Integer.parseInt(parts[i].trim());
            } catch (Exception ignored) { }
        }
        if (v[0] < 32) v[0] = 32;
        if (v[0] > 160) v[0] = 160;
        if (v[1] < 0) v[1] = 0;
        if (v[1] > 12) v[1] = 12;
        if (v[2] < 0) v[2] = 0;
        if (v[2] > 255) v[2] = 255;
        if (v[3] < 0) v[3] = 0;
        if (v[3] > 100) v[3] = 100;
        if (v[5] < 0 || v[5] > 6) v[5] = 0;
        if (v[6] < 0) v[6] = 0;
        if (v[6] > 50) v[6] = 50;
        if (v[7] < 50) v[7] = 50;
        if (v[7] > 200) v[7] = 200;
        return v;
    }

    private final LinkedHashMap<String, FloatBtn> buttons = new LinkedHashMap<String, FloatBtn>();
    /** 当前被按住（长按中）的按钮：id -> 宏名 */
    private final LinkedHashMap<String, String> held = new LinkedHashMap<String, String>();

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        posPrefs = getSharedPreferences("float_pos", MODE_PRIVATE);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String id = intent.getStringExtra("id");
            String macro = intent.getStringExtra("macro");
            String label = intent.getStringExtra("label");
            String cfg = intent.getStringExtra("cfg");
            if (macro != null && macro.length() > 0) {
                if (id == null || id.length() == 0) id = macro;
                addButton(id, macro, label == null ? "" : label, cfg);
            }
        }
        startForegroundCompat();
        if (buttons.isEmpty()) stopSelf();
        return START_NOT_STICKY;
    }

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent stop = new Intent(this, FloatLauncherActivity.class);
        stop.putExtra("action", "stop");
        stop.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "悬浮按钮",
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle("映射悬浮按钮运行中（" + buttons.size() + " 个）")
                .setContentText("点此通知可关闭全部悬浮按钮")
                .setContentIntent(pi);
        startForeground(1, b.build());
    }

    private void addButton(String id, String macro, String label, String cfg) {
        removeViewOnly(id);   // 同 id 重复添加：刷新
        int[] c = parseCfg(cfg);
        int hpx = dp(c[0]);
        int wpx = Math.max(dp(32), hpx * c[7] / 100);
        int size = Math.min(wpx, hpx);
        int borderPx = c[1] == 0 ? 0 : Math.max(1, dp(c[1]));
        int fill = c[2];

        FloatBtn b = new FloatBtn();
        b.id = id;
        b.macro = macro;
        b.locked = c[4] == 1;
        b.view = new TextView(this);
        b.view.setText(label.length() > 4 ? label.substring(0, 4) : label);
        b.view.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.28f);
        b.view.setTypeface(Typeface.DEFAULT_BOLD);
        b.view.setGravity(Gravity.CENTER);
        b.view.setTextColor(Color.rgb(28, 28, 30));
        b.bgNormal = new ShapeBg(c[5], c[6], Color.argb(fill, 255, 255, 255),
                Color.argb(210, 255, 255, 255), borderPx);
        b.bgPressed = new ShapeBg(c[5], c[6], Color.argb(Math.min(255, fill + 60), 120, 180, 255),
                Color.argb(230, 0, 122, 255), borderPx);
        b.view.setBackground(b.bgNormal);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        b.lp = new WindowManager.LayoutParams(wpx, hpx, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        b.lp.gravity = Gravity.TOP | Gravity.START;
        // 内部模糊：Android 12+ 模糊悬浮窗后面的内容（需系统开启窗口模糊，区域为按钮所在的方形范围）
        if (c[3] > 0 && Build.VERSION.SDK_INT >= 31) {
            b.lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
            b.lp.setBlurBehindRadius(c[3]);
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int defX = dm.widthPixels - wpx - dp(16);
        int defY = dm.heightPixels / 2 + buttons.size() * dp(76);
        if (defY > dm.heightPixels - hpx - dp(40)) defY = dp(120) + buttons.size() * dp(8);
        b.lp.x = posPrefs.getInt("x_" + id, defX);
        b.lp.y = posPrefs.getInt("y_" + id, defY);

        b.view.setOnTouchListener(new TouchHandler(b));
        try {
            wm.addView(b.view, b.lp);
            buttons.put(id, b);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "悬浮窗创建失败：请确认已允许显示在其他应用上层",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void removeViewOnly(String id) {
        FloatBtn old = buttons.remove(id);
        if (old != null && old.view != null) {
            try {
                wm.removeView(old.view);
            } catch (Exception ignored) { }
        }
        held.remove(id);
    }

    /** 修改已显示按钮的外观/固定状态；没有显示的按钮不会被创建 */
    public void updateButton(String id, String macro, String label, String cfg) {
        FloatBtn old = buttons.get(id);
        if (old == null) return;
        posPrefs.edit().putInt("x_" + id, old.lp.x).putInt("y_" + id, old.lp.y).apply();
        addButton(id, macro, label == null ? "" : label, cfg);
    }

    /** 关闭单个悬浮按钮（由 FloatLauncherActivity 调用） */
    public void removeButtonById(String id) {
        removeViewOnly(id);
        refreshHold();
        if (buttons.isEmpty()) {
            stopSelf();
        } else {
            startForegroundCompat();
        }
    }

    private void warnNoIme() {
        Toast.makeText(getApplicationContext(),
                "请先切换到「映射」输入法，并点开一个输入框", Toast.LENGTH_SHORT).show();
    }

    /** 按住状态变化后：没人按住就停止；还有别的按钮按着就改为循环它 */
    private void refreshHold() {
        MapInputMethodService s = MapInputMethodService.instance;
        if (s == null) return;
        if (held.isEmpty()) {
            s.stopHold();
        } else {
            String last = null;
            for (String m : held.values()) last = m;
            s.startHold(last);
        }
    }

    private class TouchHandler implements View.OnTouchListener, Runnable {
        private final FloatBtn b;
        private float downX, downY;
        private int startX, startY;
        private boolean moved, holding;
        private final int slop = ViewConfiguration.get(FloatService.this).getScaledTouchSlop();

        TouchHandler(FloatBtn b) {
            this.b = b;
        }

        /** 长按触发：开始循环输入 */
        @Override
        public void run() {
            holding = true;
            b.view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            MapInputMethodService s = MapInputMethodService.instance;
            if (s == null) {
                warnNoIme();
            } else {
                held.put(b.id, b.macro);
                s.startHold(b.macro);
            }
        }

        @Override
        public boolean onTouch(View v, MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = ev.getRawX();
                    downY = ev.getRawY();
                    startX = b.lp.x;
                    startY = b.lp.y;
                    moved = false;
                    holding = false;
                    b.view.setBackground(b.bgPressed);
                    handler.postDelayed(this, LONG_PRESS_MS);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!holding && !b.locked) {
                        float dx = ev.getRawX() - downX;
                        float dy = ev.getRawY() - downY;
                        if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                            moved = true;
                            handler.removeCallbacks(this);
                        }
                        if (moved) {
                            b.lp.x = startX + (int) dx;
                            b.lp.y = startY + (int) dy;
                            try {
                                wm.updateViewLayout(b.view, b.lp);
                            } catch (Exception ignored) { }
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(this);
                    b.view.setBackground(b.bgNormal);
                    MapInputMethodService s = MapInputMethodService.instance;
                    if (holding) {
                        held.remove(b.id);
                        refreshHold();
                    } else if (moved) {
                        posPrefs.edit().putInt("x_" + b.id, b.lp.x).putInt("y_" + b.id, b.lp.y).apply();
                    } else if (ev.getActionMasked() == MotionEvent.ACTION_UP) {
                        if (s == null) warnNoIme(); else s.tapOnce(b.macro);
                    }
                    holding = false;
                    return true;
                default:
                    return true;
            }
        }
    }

    @Override
    public void onDestroy() {
        for (Map.Entry<String, FloatBtn> e : buttons.entrySet()) {
            try {
                wm.removeView(e.getValue().view);
            } catch (Exception ignored) { }
        }
        buttons.clear();
        held.clear();
        MapInputMethodService s = MapInputMethodService.instance;
        if (s != null) s.stopHold();
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
