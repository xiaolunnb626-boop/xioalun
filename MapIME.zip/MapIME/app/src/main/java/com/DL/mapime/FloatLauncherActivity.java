package com.DL.mapime;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

/** 透明中转页：检查悬浮窗权限，然后启动 / 关闭悬浮按钮服务。 */
public class FloatLauncherActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = getIntent();
        String action = in == null ? null : in.getStringExtra("action");

        if ("stop".equals(action)) {
            stopService(new Intent(this, FloatService.class));
            Toast.makeText(this, "悬浮按钮已关闭", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先允许「映射输入法」显示在其他应用上层，再回去点一次创建",
                    Toast.LENGTH_LONG).show();
            Intent p = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(p);
            finish();
            return;
        }

        Intent s = new Intent(this, FloatService.class);
        s.putExtra("macro", in == null ? "" : in.getStringExtra("macro"));
        s.putExtra("label", in == null ? "" : in.getStringExtra("label"));
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(s);
        } else {
            startService(s);
        }
        Toast.makeText(this, "悬浮按钮已创建：切到目标应用，点开输入框，长按悬浮按钮",
                Toast.LENGTH_LONG).show();
        finish();
    }
}
