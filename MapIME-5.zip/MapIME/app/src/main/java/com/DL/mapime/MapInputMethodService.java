package com.DL.mapime;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * 「映射」输入法：按绑定的音量键执行宏（逐步 commitText + 毫秒延迟）。
 *
 * 循环的实现方式（不依赖定时器，也不依赖松手事件）：
 *   按住音量键时系统会不断发来“按住重复”事件；每收到一个事件，如果宏当前没在执行，
 *   就把宏完整执行一遍。宏跑完后，下一个重复事件到来时再跑一遍，所以会一直循环；
 *   松手后不再有事件，自然就停了（收到松手事件时还会立即中断当前这一遍）。
 * 关闭“循环”的宏：每次按下只执行一遍。
 */
public class MapInputMethodService extends InputMethodService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MacroStore store;
    private TextView tipView;

    private boolean consumingVolume = false;
    private boolean active = false;        // 宏正在执行
    private boolean pressLoop = false;     // 本次按压绑定的宏是否为循环模式
    private boolean pressStarted = false;  // 本次按压是否已经执行过（单次模式用）
    private long runToken = 0L;

    // 调试计数，显示在键盘条上
    private int downCount = 0, repeatCount = 0, upCount = 0;
    private int commitCount = 0, noIcCount = 0, rounds = 0;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        store = new MacroStore(this);
    }

    @Override
    public boolean onEvaluateInputViewShown() {
        return true;
    }

    @Override
    public View onCreateInputView() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(8), dp(16), dp(8));
        bar.setMinimumHeight(dp(60));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(235, 245, 245, 247));
        bg.setStroke(dp(1), Color.argb(60, 0, 0, 0));
        bar.setBackground(bg);

        TextView tip = new TextView(this);
        tipView = tip;
        tip.setText("映射已启用 · 按住音量键触发宏");
        tip.setTextSize(13);
        tip.setTextColor(Color.rgb(28, 28, 30));
        bar.addView(tip, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView switcher = new TextView(this);
        switcher.setText("切换输入法");
        switcher.setTextSize(14);
        switcher.setTextColor(Color.rgb(0, 122, 255));
        switcher.setGravity(Gravity.CENTER);
        switcher.setPadding(dp(14), 0, dp(14), 0);
        GradientDrawable btn = new GradientDrawable();
        btn.setCornerRadius(dp(14));
        btn.setColor(Color.argb(40, 0, 122, 255));
        btn.setStroke(dp(1), Color.argb(130, 0, 122, 255));
        switcher.setBackground(btn);
        switcher.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        });
        bar.addView(switcher, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)));
        return bar;
    }

    private void updateTip() {
        if (tipView != null) {
            tipView.setText("按下" + downCount + " 重复" + repeatCount + " 抬起" + upCount
                    + " 输入" + commitCount + " 无连接" + noIcCount + " 轮" + rounds
                    + (active ? " · 执行中" : " · 空闲"));
        }
    }

    /** 把宏完整执行一遍 */
    private void runOnce(String name) {
        List<MacroStore.Step> steps = store.steps(name);
        if (steps.isEmpty()) return;
        long token = ++runToken;
        active = true;
        runStep(steps, 0, token);
    }

    private void stopRun() {
        active = false;
        ++runToken;
        handler.removeCallbacksAndMessages(null);
    }

    private void runStep(final List<MacroStore.Step> steps, final int index, final long token) {
        if (token != runToken || !active) return;
        if (index >= steps.size()) {   // 这一遍跑完
            active = false;
            rounds++;
            updateTip();
            return;
        }
        MacroStore.Step s = steps.get(index);

        InputConnection ic = getCurrentInputConnection();
        if (ic != null && s.text.length() > 0) {
            ic.commitText(s.text, 1);
            commitCount++;
        } else if (ic == null) {
            noIcCount++;
        }
        updateTip();
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                runStep(steps, index + 1, token);
            }
        }, s.delay);
    }

    private boolean handleVolume(int keyCode, KeyEvent event) {
        if (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false;
        }
        String macro = store.boundMacro(keyCode == KeyEvent.KEYCODE_VOLUME_UP);
        if (macro == null || macro.length() == 0) return false;

        consumingVolume = true;
        boolean isRepeat = event != null && event.getRepeatCount() > 0;
        if (isRepeat) {
            repeatCount++;
        } else {
            downCount++;
            pressStarted = false;   // 全新的一次按下
        }

        boolean loop = store.isLoop(macro);
        pressLoop = loop;
        if (!active) {
            // 循环模式：每个事件到来时空闲就再跑一遍；单次模式：每次按下只跑一遍
            if (loop || !pressStarted) {
                pressStarted = true;
                runOnce(macro);
            }
        }
        updateTip();
        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (handleVolume(keyCode, event)) return true;
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                && consumingVolume) {
            consumingVolume = false;
            pressStarted = false;
            upCount++;
            if (pressLoop) stopRun();   // 循环模式：松手立即中断；单次模式让它执行完
            updateTip();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onFinishInput() {
        stopRun();
        super.onFinishInput();
    }

    @Override
    public void onDestroy() {
        stopRun();
        super.onDestroy();
    }
}
