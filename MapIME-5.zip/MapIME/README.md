# 映射输入法（独立 APK）

1. 用 Android Studio 打开本文件夹（File → Open），等待 Gradle 同步（首次需联网，会自动下载 Gradle 8.2 / AGP 8.2.2）。
2. Build → Build APK(s)，安装生成的 app-debug.apk。
3. 打开「映射输入法」App → ① 启用「映射」→ 回到任意输入框，② 或在「高级底栏」里点“添加映射”呼出选择器，选「映射」。
4. 在「高级底栏」(包名 com.DL) 里创建宏并绑定音量键，数据会自动同步到本应用。
   如果高级底栏的包名不是 com.DL，请修改 MacroProvider.java 里的 ALLOWED_CALLER。
