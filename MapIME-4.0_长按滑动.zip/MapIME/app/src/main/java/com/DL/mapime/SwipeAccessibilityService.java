package com.DL.mapime;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Rect;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

/**
 * 滚动辅助服务：悬浮按钮「长按后滑动」时，找到按钮位置下方可滚动的控件，
 * 对它执行无障碍滚动动作（按页滚动）。
 *
 * 为什么不用 dispatchGesture 重放手指轨迹：系统的无障碍输入过滤器会在收到任何真实触摸事件时，
 * 取消正在进行的注入手势；而长按滑动时手指一直按在屏幕上，注入的手势会被立刻取消，所以没有效果。
 * 无障碍滚动动作不走触摸事件，不会被取消。
 */
public class SwipeAccessibilityService extends AccessibilityService {
    static volatile SwipeAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        if (instance == this) instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    /**
     * 在屏幕坐标 (x,y) 处找最内层的可滚动控件并滚动一页。
     * dx/dy 为手指滑动方向：手指向上滑(dy<0)=内容向下滚。
     *
     * @return 是否成功执行了滚动
     */
    public boolean scrollAt(int x, int y, float dx, float dy) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo target = findScrollable(root, x, y, 0);
        if (target == null) return false;

        boolean vertical = Math.abs(dy) >= Math.abs(dx);
        boolean ok = false;
        if (Build.VERSION.SDK_INT >= 23) {
            AccessibilityNodeInfo.AccessibilityAction act;
            if (vertical) {
                act = dy < 0 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN
                        : AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP;
            } else {
                act = dx < 0 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT
                        : AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT;
            }
            if (target.getActionList().contains(act)) {
                ok = target.performAction(act.getId());
            }
        }
        if (!ok) {
            // 没有方向性动作时退回到前进/后退
            boolean forward = vertical ? dy < 0 : dx < 0;
            ok = target.performAction(forward
                    ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
        }
        return ok;
    }

    /** 深度优先：返回包含 (x,y) 的最内层可滚动节点 */
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo node, int x, int y, int depth) {
        if (node == null || depth > 40) return null;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (!r.contains(x, y)) return null;
        AccessibilityNodeInfo best = null;
        int n = node.getChildCount();
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo hit = findScrollable(node.getChild(i), x, y, depth + 1);
            if (hit != null) best = hit;   // 后面的子节点在上层，覆盖前面的
        }
        if (best != null) return best;
        return node.isScrollable() ? node : null;
    }
}
