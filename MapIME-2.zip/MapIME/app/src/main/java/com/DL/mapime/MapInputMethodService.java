package com.DL.mapime;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** 「映射」输入法：激活且有输入框时，按绑定的音量键执行宏（逐步 commitText + 毫秒延迟）。 */
public class MapInputMethodService extends InputMethodService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean consumingVolume = false;
    private boolean active = false;
    private boolean loopMode = false;
    private long lastKeyTime = 0L;
    /** 超过这个时间没收到按键事件（按住时系统会持续发送），视为已松手，防止卡死循环 */
    private static final long HOLD_TIMEOUT = 1200L;
    private long runToken = 0L;
    private MacroStore store;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        store = new MacroStore(this);
    }

    @Override
    public boolean onEvaluateInputViewShown() {
        return true;
    }

    @Override
    public View onCreateInputView() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(8), dp(16), dp(8));
        bar.setMinimumHeight(dp(60));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(235, 245, 245, 247));
        bg.setStroke(dp(1), Color.argb(60, 0, 0, 0));
        bar.setBackground(bg);

        TextView tip = new TextView(this);
        tip.setText("映射已启用 · 音量键触发宏");
        tip.setTextSize(14);
        tip.setTextColor(Color.rgb(28, 28, 30));
        bar.addView(tip, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView switcher = new TextView(this);
        switcher.setText("切换输入法");
        switcher.setTextSize(14);
        switcher.setTextColor(Color.rgb(0, 122, 255));
        switcher.setGravity(Gravity.CENTER);
        switcher.setPadding(dp(14), 0, dp(14), 0);
        GradientDrawable btn = new GradientDrawable();
        btn.setCornerRadius(dp(14));
        btn.setColor(Color.argb(40, 0, 122, 255));
        btn.setStroke(dp(1), Color.argb(130, 0, 122, 255));
        switcher.setBackground(btn);
        switcher.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        });
        bar.addView(switcher, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)));
        return bar;
    }

    private void startMacro(String name, boolean loop) {
        List<MacroStore.Step> steps = store.steps(name);
        if (steps.isEmpty()) return;
        long token = ++runToken;
        active = true;
        loopMode = loop;
        runStep(steps, 0, token);
    }

    private void stopLoop() {
        active = false;
        loopMode = false;
        ++runToken;
        handler.removeCallbacksAndMessages(null);
    }

    private void runStep(final List<MacroStore.Step> steps, final int index, final long token) {
        if (token != runToken || !active) return;
        if (loopMode && SystemClock.uptimeMillis() - lastKeyTime > HOLD_TIMEOUT) {
            stopLoop();
            return;
        }
        if (index >= steps.size()) {
            if (!loopMode) {   // 单次模式：执行完就结束
                active = false;
                return;
            }
            // 循环模式：只要还按着，就从第一步重新开始
            handler.postDelayed(new Runnable() {
                @Override public void run() {
                    runStep(steps, 0, token);
                }
            }, 20L);
            return;
        }
        MacroStore.Step s = steps.get(index);

        InputConnection ic = getCurrentInputConnection();
        if (ic != null && s.text.length() > 0) {
            ic.commitText(s.text, 1);
        }
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                runStep(steps, index + 1, token);
            }
        }, s.delay);
    }

    private boolean handleVolume(int keyCode, KeyEvent event) {
        if (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false;
        }
        String macro = store.boundMacro(keyCode == KeyEvent.KEYCODE_VOLUME_UP);
        if (macro == null || macro.length() == 0) return false;
        lastKeyTime = SystemClock.uptimeMillis();
        consumingVolume = true;
        // 按下开始；按住期间的重复事件只刷新时间戳（循环模式靠它判断是否仍按着）
        if (event == null || event.getRepeatCount() == 0) {
            startMacro(macro, store.isLoop(macro));
        }
        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (handleVolume(keyCode, event)) return true;
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                && consumingVolume) {
            consumingVolume = false;
            if (loopMode) stopLoop();   // 循环模式：松手立即停止；单次模式让它执行完
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onFinishInput() {
        stopLoop();
        super.onFinishInput();
    }

    @Override
    public void onDestroy() {
        stopLoop();
        super.onDestroy();
    }
}
