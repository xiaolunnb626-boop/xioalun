package com.DL.mapime;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

/**
 * 「高级底栏」通过 ContentResolver.call(uri, "set", json, null) 把宏同步进来。
 * 只允许 ALLOWED_CALLER（高级底栏的包名）和本应用自己调用。
 */
public class MacroProvider extends ContentProvider {
    /** 高级底栏的包名（config.json 里的 package） */
    private static final String ALLOWED_CALLER = "com.DL";

    @Override
    public boolean onCreate() {
        return true;
    }

    private void checkCaller() {
        String caller = getCallingPackage();
        String self = getContext().getPackageName();
        if (caller == null || !(caller.equals(ALLOWED_CALLER) || caller.equals(self))) {
            throw new SecurityException("caller not allowed: " + caller);
        }
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        checkCaller();
        MacroStore store = new MacroStore(getContext());
        Bundle out = new Bundle();
        if ("set".equals(method)) {
            store.saveJson(arg);
            out.putBoolean("ok", true);
        } else if ("get".equals(method)) {
            out.putString("json", store.getJson());
            out.putBoolean("ok", true);
        } else {
            out.putBoolean("ok", false);
        }
        return out;
    }

    @Override public Cursor query(Uri uri, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { return 0; }
}
