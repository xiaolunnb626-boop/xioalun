package com.DL.mapime;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

/**
 * 透明中转页（由「游戏映射」拉起）。extras：
 *   action = "show"（默认）：添加/刷新一个悬浮按钮，需要 id、macro、label
 *   action = "update"：修改已显示按钮的外观（cfg），没显示则忽略
 *   action = "remove"：关闭 id 对应的那一个悬浮按钮
 *   action = "stop"  ：关闭全部悬浮按钮
 */
public class FloatLauncherActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = getIntent();
        String action = in == null ? null : in.getStringExtra("action");
        String id = in == null ? null : in.getStringExtra("id");
        String macro = in == null ? null : in.getStringExtra("macro");
        String label = in == null ? null : in.getStringExtra("label");

        if ("stop".equals(action)) {
            stopService(new Intent(this, FloatService.class));
            Toast.makeText(this, "悬浮按钮已全部关闭", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        String cfg = in == null ? null : in.getStringExtra("cfg");
        if ("update".equals(action)) {
            FloatService s = FloatService.instance;
            if (s != null && id != null) s.updateButton(id, macro == null ? "" : macro, label, cfg);
            finish();
            return;
        }
        if ("remove".equals(action)) {
            FloatService s = FloatService.instance;
            if (s != null && id != null) s.removeButtonById(id);
            finish();
            return;
        }

        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先允许「映射输入法」显示在其他应用上层，再回去点一次显示",
                    Toast.LENGTH_LONG).show();
            Intent p = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(p);
            finish();
            return;
        }

        Intent s = new Intent(this, FloatService.class);
        s.putExtra("id", id == null || id.length() == 0 ? macro : id);
        s.putExtra("macro", macro == null ? "" : macro);
        s.putExtra("label", label == null ? "" : label);
        if (cfg != null) s.putExtra("cfg", cfg);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(s);
        } else {
            startService(s);
        }
        Toast.makeText(this, "悬浮按钮已显示：切到目标应用，点开输入框，长按悬浮按钮",
                Toast.LENGTH_SHORT).show();
        finish();
    }
}
