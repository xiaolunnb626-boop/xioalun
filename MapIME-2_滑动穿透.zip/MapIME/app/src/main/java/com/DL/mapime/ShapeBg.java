package com.DL.mapime;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/**
 * 悬浮按钮背景：可选形状 + 填充 + 边框。
 * shape：0 圆形/椭圆  1 圆角矩形（cornerPct 为圆角占短边的百分比 0-50）
 *        2 胶囊  3 菱形  4 六边形  5 星形  6 正方形（直角矩形）
 */
public class ShapeBg extends Drawable {
    private final int shape, cornerPct;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float strokeW;

    public ShapeBg(int shape, int cornerPct, int fillColor, int strokeColor, float strokeW) {
        this.shape = shape;
        this.cornerPct = Math.max(0, Math.min(50, cornerPct));
        this.strokeW = strokeW;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(fillColor);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setColor(strokeColor);
        stroke.setStrokeWidth(strokeW);
        if (shape >= 3) {   // 多边形顶点做一点圆角，更柔和
            CornerPathEffect fx = new CornerPathEffect(Math.max(2f, strokeW * 2f));
            fill.setPathEffect(fx);
            stroke.setPathEffect(fx);
        }
    }

    private Path buildPath(RectF r) {
        Path p = new Path();
        float w = r.width(), h = r.height(), cx = r.centerX(), cy = r.centerY();
        float m = Math.min(w, h);
        switch (shape) {
            case 1: {
                float rad = m * cornerPct / 100f;
                p.addRoundRect(r, rad, rad, Path.Direction.CW);
                break;
            }
            case 2:
                p.addRoundRect(r, m / 2f, m / 2f, Path.Direction.CW);
                break;
            case 6:
                p.addRect(r, Path.Direction.CW);
                break;
            case 3:
                p.moveTo(cx, r.top);
                p.lineTo(r.right, cy);
                p.lineTo(cx, r.bottom);
                p.lineTo(r.left, cy);
                p.close();
                break;
            case 4:
                p.moveTo(r.left + w * 0.25f, r.top);
                p.lineTo(r.right - w * 0.25f, r.top);
                p.lineTo(r.right, cy);
                p.lineTo(r.right - w * 0.25f, r.bottom);
                p.lineTo(r.left + w * 0.25f, r.bottom);
                p.lineTo(r.left, cy);
                p.close();
                break;
            case 5: {
                float ro = m / 2f, ri = ro * 0.45f;
                for (int i = 0; i < 10; i++) {
                    double a = -Math.PI / 2 + i * Math.PI / 5;
                    float rr = (i % 2 == 0) ? ro : ri;
                    float x = cx + (float) (rr * Math.cos(a)) * (w / m);
                    float y = cy + (float) (rr * Math.sin(a)) * (h / m);
                    if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
                }
                p.close();
                break;
            }
            default:
                p.addOval(r, Path.Direction.CW);
        }
        return p;
    }

    @Override
    public void draw(Canvas c) {
        RectF r = new RectF(getBounds());
        float inset = strokeW / 2f;
        r.inset(inset, inset);
        Path p = buildPath(r);
        c.drawPath(p, fill);
        if (strokeW > 0) c.drawPath(p, stroke);
    }

    @Override public void setAlpha(int alpha) { }
    @Override public void setColorFilter(ColorFilter cf) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
