package com.DL.mapime;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.annotation.TargetApi;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;

/**
 * 无障碍手势服务：悬浮按钮「长按后滑动」时，把手指的滑动轨迹实时重放到按钮下方的应用上，
 * 让下面的应用跟着滚动。不需要 root，只需要用户在系统「无障碍」里开启本服务。
 *
 * Android 8.0+：用「可续接笔画」(continueStroke) 实时跟手；
 * Android 7.x ：只能在松手时一次性补发一次滑动。
 */
public class SwipeAccessibilityService extends AccessibilityService {
    static volatile SwipeAccessibilityService instance;

    private static final long FIRST_DELAY_MS = 50L;   // 等悬浮窗变成「不接收触摸」后再注入

    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean active, finishing, inFlight;
    private int gen = 0;   // 每次 reset 递增，丢弃过期回调
    private float startX, startY, lastX, lastY, pendX, pendY;
    private long startT, lastT, notBefore;
    private GestureDescription.StrokeDescription stroke;

    private final Runnable pumpRunnable = new Runnable() {
        @Override public void run() { pump(); }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        if (instance == this) instance = null;
        reset();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        reset();
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { reset(); }

    // ---------------------------------------------------------------- 对外接口（主线程调用）

    /** 在 (x,y) 按下，开始一次滑动 */
    public void beginSwipe(float x, float y) {
        if (Build.VERSION.SDK_INT < 24) return;
        reset();
        float[] p = clamp(x, y);
        active = true;
        startX = lastX = pendX = p[0];
        startY = lastY = pendY = p[1];
        startT = lastT = SystemClock.uptimeMillis();
        notBefore = startT + FIRST_DELAY_MS;
    }

    /** 手指移动到 (x,y) */
    public void moveSwipe(float x, float y) {
        if (!active) return;
        float[] p = clamp(x, y);
        pendX = p[0];
        pendY = p[1];
        pump();
    }

    /** 手指抬起：把剩余轨迹发完并抬手 */
    public void endSwipe() {
        if (!active) return;
        finishing = true;
        pump();
    }

    public void cancelSwipe() {
        reset();
    }

    // ---------------------------------------------------------------- 内部实现

    private float[] clamp(float x, float y) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float cx = Math.max(0f, Math.min(dm.widthPixels - 1f, x));
        float cy = Math.max(0f, Math.min(dm.heightPixels - 1f, y));
        return new float[]{cx, cy};
    }

    private void reset() {
        gen++;
        active = false;
        finishing = false;
        inFlight = false;
        stroke = null;
        handler.removeCallbacks(pumpRunnable);
    }

    @TargetApi(26)
    private void pump() {
        if (!active || inFlight) return;
        long now = SystemClock.uptimeMillis();
        if (now < notBefore) {
            handler.removeCallbacks(pumpRunnable);
            handler.postDelayed(pumpRunnable, notBefore - now);
            return;
        }

        if (Build.VERSION.SDK_INT < 26) {
            pumpLegacy(now);
            return;
        }

        final float tx = pendX, ty = pendY;
        final boolean last = finishing;
        boolean moved = Math.abs(tx - lastX) >= 1f || Math.abs(ty - lastY) >= 1f;

        if (!moved) {
            if (!last) return;                       // 没动，等下一次移动
            if (stroke == null) { reset(); return; } // 从未发出过笔画，无需抬手
        }

        Path path = new Path();
        path.moveTo(lastX, lastY);
        if (moved) path.lineTo(tx, ty);
        long dur = Math.max(10L, Math.min(80L, now - lastT));

        final GestureDescription.StrokeDescription s;
        if (stroke == null) {
            s = new GestureDescription.StrokeDescription(path, 0, dur, !last);
        } else {
            s = stroke.continueStroke(path, 0, dur, !last);
        }
        final float endX = moved ? tx : lastX;
        final float endY = moved ? ty : lastY;
        final int myGen = gen;

        inFlight = true;
        boolean ok = dispatchGesture(new GestureDescription.Builder().addStroke(s).build(),
                new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription g) {
                        if (myGen != gen || !active) return;
                        inFlight = false;
                        lastX = endX;
                        lastY = endY;
                        lastT = SystemClock.uptimeMillis();
                        stroke = s;
                        if (last) reset(); else pump();
                    }
                    @Override public void onCancelled(GestureDescription g) {
                        if (myGen != gen) return;
                        reset();
                    }
                }, handler);
        if (!ok) reset();
    }

    /** Android 7.x：只在松手时一次性补发一次滑动 */
    @TargetApi(24)
    private void pumpLegacy(long now) {
        if (!finishing) return;
        float dx = pendX - startX, dy = pendY - startY;
        if (Math.abs(dx) < 1f && Math.abs(dy) < 1f) { reset(); return; }
        Path path = new Path();
        path.moveTo(startX, startY);
        path.lineTo(pendX, pendY);
        long dur = Math.max(80L, Math.min(2000L, now - startT));
        final int myGen = gen;
        inFlight = true;
        boolean ok = dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, dur)).build(),
                new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription g) { if (myGen == gen) reset(); }
                    @Override public void onCancelled(GestureDescription g) { if (myGen == gen) reset(); }
                }, handler);
        if (!ok) reset();
    }
}
